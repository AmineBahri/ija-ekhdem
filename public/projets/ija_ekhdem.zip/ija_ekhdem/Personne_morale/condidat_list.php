<?php
include("db.php");
session_start();
	
$auth = "SELECT * FROM  personne_morale where (id_persmorale='".$_SESSION['id_per']."')";
$psw2=mysqli_query($con,$auth);
{
	while($res2=mysqli_fetch_array($psw2)) {
	$nomut=$res2[3];
	$prenomut=$res2[4];
?>
<html lang="en">

<head>

<!-- Basic Page Needs
================================================== -->
<title>IJA EKHDEM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">

<!-- Header Container
================================================== -->
<header id="header-container" class="fullwidth dashboard-header not-sticky">

	<!-- Header -->
	<div id="header">
		<div class="container">
			
			<!-- Left Side Content -->
			<div class="left-side">
				
				<!-- Logo -->
				<div id="logo">
					<a href="index-2.html"><img src="images/logo.png" alt=""></a>
				</div>

				<!-- Main Navigation -->
				<nav id="navigation">
					<ul id="responsive">

						<li><a href="#">Acceuil</a>
							<ul class="dropdown-nav">
								<li><a href="../index.php"> Acceuil</a></li>
							</ul>
						</li>
						<li><a href="#" class="current">Tableau de bord</a>
							<ul class="dropdown-nav">
								<li><a href="dashboard.html">Tableau de bord</a></li>
								<li><a href="jobs-list-layout.php">Gérer les offres</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-post-a-job.php"> Publier un offre</a></li>
										<li><a href="jobs-list-layout.php"> Consulter la liste des offres</a></li>
										
									
									</ul>
								</li>
								<li><a href="dashboard-manage-candidates.php">Gérer la liste des condidatures</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-manage-candidates.php">Consulter mes listes</li>
                                         <li><a href="find_profile.php">Rechercher un profils </li>											
									</ul>
								</li>
							<a href="dashboard-settings.php">Paramètres</a>
							</ul>
						</li>
					</ul>
				</nav>
				<div class="clearfix"></div>
				<!-- Main Navigation / End -->
				
			</div>
			<!-- Left Side Content / End -->


			<!-- Right Side Content / End -->
			<div class="right-side">

	            <!--  User Notifications / End -->

				<!-- User Menu -->
				<div class="header-widget">

					<!-- Messages -->
					<div class="header-notifications user-menu">
						<div class="header-notifications-trigger">
							<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
						</div>

						<!-- Dropdown -->
						<div class="header-notifications-dropdown">

							<!-- User Status -->
							<div class="user-status">

								<!-- User Name / Avatar -->
								<div class="user-details">
									<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
									<div class="user-name">
									<?= 
$res2[3] ?> <?= 
$res2[2] ;}}?>  <span>Employeur</span>
									</div>
								</div>
								
								<!-- User Status Switcher -->
								<div class="status-switch" id="snackbar-user-status">
									<label class="user-online current-status">Online</label>
									<label class="user-invisible">Invisible</label>
									<!-- Status Indicator -->
									<span class="status-indicator" aria-hidden="true"></span>
								</div>	
						</div>
						
						<ul class="user-menu-small-nav">
							<li><a href="dashboard_pers_morale.php"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Logout</li>
						</ul>

						</div>
					</div>

				</div>
				<!-- User Menu / End -->

				<!-- Mobile Navigation Button -->
				<span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

			</div>
			<!-- Right Side Content / End -->

		</div>
	</div>
	<!-- Header / End -->

</header>
<div class="clearfix"></div>
<!-- Header Container / End -->


<!-- Dashboard Container -->
<div class="dashboard-container">

	<!-- Dashboard Sidebar
	================================================== -->
	<div class="dashboard-sidebar">
		<div class="dashboard-sidebar-inner" data-simplebar>
			<div class="dashboard-nav-container">

				<!-- Responsive Navigation Trigger -->
				<a href="#" class="dashboard-responsive-nav-trigger">
					<span class="hamburger hamburger--collapse" >
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</span>
					<span class="trigger-title">Dashboard Navigation</span>
				</a>
				
				<!-- Navigation -->
				<div class="dashboard-nav">
					<div class="dashboard-nav-inner">
						<ul data-submenu-title="Manage Accounts">
							<li><a href="#"><i class="icon-material-outline-business-center"></i> Gérer les offres</a>
								<ul>
									<li><a href="dashboard-post-a-job.php">Publier un offre </a></li>
									<li><a href="jobs-list-layout.php">Consulter la liste des offres </a></li>
								
								

								</ul>	
							</li>
							<li><a href="#"><i class="icon-material-outline-assignment"></i> Gérer la liste des  condidatures</a>
								<ul>
									<li><a href="condidat_list.php">Consulter mes listes </a></li>
								</ul>		
							</li>
							
							<li><a href="find_profile.php"><i class=""></i> Rechercher un profils</a>
								
							</li>
						</ul>

						<ul data-submenu-title="Mon Compte">
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Déconnexion</a></li>
						</ul>
						
					</div>
				</div>
				<!-- Navigation / End -->

			</div>
		</div>
	</div>
	<!-- Dashboard Sidebar / End -->

<div class="clearfix"></div>
<!-- Header Container / End -->

<!-- Spacer -->
<div class="margin-top-90"></div>
<!-- Spacer / End-->

<!-- Page Content
================================================== -->
<div class="container">
	<div class="row">
		<div class="col-xl-3 col-lg-4">
			
		</div>
		<div class="col-xl-9 col-lg-8 content-left-offset">

			<h3 class="page-title">Résultats de recherche</h3>

			<div class="notify-box margin-top-15">
				<div class="switch-container">
					<label class="switch"><input type="checkbox"><span class="switch-button"></span><span class="switch-text">Turn on email alerts for this search</span></label>
				</div>

				<div class="sort-by">
					<span>Trier par:</span>
					<select class="selectpicker hide-tick">
						<option>Relevance</option>
						<option>Newest</option>
						<option>Oldest</option>
						<option>Random</option>
					</select>
				</div>
			</div>

  
			<!-- Freelancers List Container -->
			<div class="freelancers-container freelancers-list-layout compact-list margin-top-35">
		
	<?php 

  
	$sql2 = "SELECT * FROM  demande_emploi1 ";
  $psw2=mysqli_query($con,$sql2);
  {
	  while($res2=mysqli_fetch_array($psw2)) {
	  $pw20=$res2[3];
	  $pw21=$res2[2];
	 
	  
     $sql4 = "SELECT * FROM  offre_emploi";
     $psw4=mysqli_query($con,$sql4);
  {
	  while($res4=mysqli_fetch_array($psw4)) {
	  $pw40=$res4[14];
	  $idemp=$res4[0];
	  
	  if($res4[14] == $_SESSION['id_per'] and $res4[0]==$res2[3])
	  {
   $sql1 = "SELECT * FROM utilisateur";
  $psw=mysqli_query($con,$sql1);
  while($res1=mysqli_fetch_array($psw)) {
	  if($res2[2] == $res1[0])
	  {
      $id=$res1[0];
	  $pw=$res1['cin'];
	  $pw1=$res1['nom'];
	  $pw2=$res1['prenom'];
	  $pw3=$res1['email'];
	  $pw4=$res1['adresse'];
	  $pw5=$res1['telephone'];
	  $pw6=$res1['date_naissance'];
       //echo $pw;
	  
	$sql5 = "SELECT * FROM  offre_emploi  ";
     $psw5=mysqli_query($con,$sql5);
  {
	  while($res5=mysqli_fetch_array($psw5)) {
	  $pw50=$res5[0];
	  $pw51=$res5[1];
	  {
		  if(($res5[0]== $res2[3])and($res1[0]==$res2[2])){
			  //echo $pw50;
	   
echo"	   
				<!--Freelancer -->
				<div class='freelancer'>

					<!-- Overview -->
					<div class='freelancer-overview'>
						<div class='freelancer-overview-inner'>
							
							<!-- Bookmark Icon -->
							<span class='bookmark-icon'></span>
							
							<!-- Avatar -->
							<div class='freelancer-avatar'>
								<div class='verified-badge'></div>
								<a href='single-freelancer-profile.html'><img src='images/user-avatar-big-01.jpg' ></a>
							</div> 
							<!-- Name -->
							<div class='freelancer-name'>
								<h4><a href='#'>$pw1 &nbsp $pw2  </a></h4>";
								$sqlii = "SELECT * FROM projet  where (id_utilisateur=$id) AND (id_offreemploi =  $pw20)";
								$prog=mysqli_query($con,$sqlii);

								while($prog1=mysqli_fetch_array($prog)) {
									echo "  
								<span> <a href=".$prog1['url_projet']." class='button ripple-effect'><i class='icon-feather-mail'></i> Download Projet ".$prog1['nom_projet']." </a></span>
								" ;
								}
								echo "
								<div class='freelancer-rating'>
								Offre en cours:
									<div class='star-rating' data-rating='$pw51'></div>
								</div>
								
							</div>
						</div>
					</div>
					<!-- Details -->
					<div class='freelancer-details'>
						<div class='freelancer-details-list'>
							<ul>
								<li>CIN <strong>$pw</strong></li>
								<li>Email <strong> $pw3</strong></li>
								<li>Adresse <strong><i class='icon-material-outline-location-on'></i> $pw4  </strong></li>
								
							
							</ul>
						</div>
						<a href='profile.php?id=$id' class='button button-sliding-icon ripple-effect'>View Profile <i class='icon-material-outline-arrow-right-alt'></i></a>
					</div>
				</div>";
	  }  }}
  }}
  }}
  }
  }}}	
	  
				
?>
				
	
			</div>
			<!-- Freelancers Container / End -->
			


			<!-- Pagination -->
			<div class="clearfix"></div>
			<div class="row">
				<div class="col-md-12">
					<!-- Pagination -->
					<div class="pagination-container margin-top-40 margin-bottom-60">
						<nav class="pagination">
							<ul>
								<li class="pagination-arrow"><a href="#" class="ripple-effect"><i class="icon-material-outline-keyboard-arrow-left"></i></a></li>
								<li><a href="#" class="ripple-effect">1</a></li>
								<li><a href="#" class="current-page ripple-effect">2</a></li>
								<li><a href="#" class="ripple-effect">3</a></li>
								<li><a href="#" class="ripple-effect">4</a></li>
								<li class="pagination-arrow"><a href="#" class="ripple-effect"><i class="icon-material-outline-keyboard-arrow-right"></i></a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
			<!-- Pagination / End -->

		</div>
	</div>
</div>
</div>

<!-- Footer
================================================== -->
<div id="footer">
	
	<!-- Footer Top Section -->
	<div class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">

					<!-- Footer Rows Container -->
					<div class="footer-rows-container">
						
						<!-- Left Side -->
						<div class="footer-rows-left">
							<div class="footer-row">
								<div class="footer-row-inner footer-logo">
									<img src="images/logo2.png" alt="">
								</div>
							</div>
						</div>
						
						<!-- Right Side -->
						<div class="footer-rows-right">

							<!-- Social Icons -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<ul class="footer-social-links">
										<li>
											<a href="#" title="Facebook" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-facebook-f"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Twitter" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-twitter"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Google Plus" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-google-plus-g"></i>
											</a>
										</li>
										<li>
											<a href="#" title="LinkedIn" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-linkedin-in"></i>
											</a>
										</li>
									</ul>
									<div class="clearfix"></div>
								</div>
							</div>
							
							<!-- Language Switcher -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<select class="selectpicker language-switcher" data-selected-text-format="count" data-size="5">
										<option selected>English</option>
										<option>Français</option>
										<option>Español</option>
										<option>Deutsch</option>
									</select>
								</div>
							</div>
						</div>

					</div>
					<!-- Footer Rows Container / End -->
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Top Section / End -->

	<!-- Footer Middle Section -->
	<div class="footer-middle-section">
		<div class="container">
			<div class="row">

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>For Candidates</h3>
						<ul>
							<li><a href="#"><span>Browse Jobs</span></a></li>
							<li><a href="#"><span>Add Resume</span></a></li>
							<li><a href="#"><span>Job Alerts</span></a></li>
							<li><a href="#"><span>My Bookmarks</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>For Employers</h3>
						<ul>
							<li><a href="#"><span>Browse Candidates</span></a></li>
							<li><a href="#"><span>Post a Job</span></a></li>
							<li><a href="#"><span>Post a Task</span></a></li>
							<li><a href="#"><span>Plans & Pricing</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Helpful Links</h3>
						<ul>
							<li><a href="#"><span>Contact</span></a></li>
							<li><a href="#"><span>Privacy Policy</span></a></li>
							<li><a href="#"><span>Terms of Use</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Account</h3>
						<ul>
							<li><a href="#"><span>Log In</span></a></li>
							<li><a href="#"><span>My Account</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Newsletter -->
				<div class="col-xl-4 col-lg-4 col-md-12">
					<h3><i class="icon-feather-mail"></i> Sign Up For a Newsletter</h3>
					<p>Weekly breaking news, analysis and cutting edge advices on job searching.</p>
					<form action="#" method="get" class="newsletter">
						<input type="text" name="fname" placeholder="Enter your email address">
						<button type="submit"><i class="icon-feather-arrow-right"></i></button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Middle Section / End -->
	
	<!-- Footer Copyrights -->
	<div class="footer-bottom-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					© 2019 <strong>Hireo</strong>. All Rights Reserved.
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Copyrights / End -->

</div>
<!-- Footer / End -->

</div>
<!-- Wrapper / End -->

<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 
</script>

<!-- Google Autocomplete -->
<script>
	function initAutocomplete() {
		 var options = {
		  types: ['(cities)'],
		  // componentRestrictions: {country: "us"}
		 };

		 var input = document.getElementById('autocomplete-input');
		 var autocomplete = new google.maps.places.Autocomplete(input, options);
	}
</script>

<!-- Google API & Maps -->
<!-- Geting an API Key: https://developers.google.com/maps/documentation/javascript/get-api-key -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&amp;libraries=places"></script>

</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/freelancers-list-layout-1.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:38:59 GMT -->
</html>