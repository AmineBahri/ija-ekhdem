<?php
include("db.php");
session_start();
//bouton refuser condidature
if(isset($_GET['refuse'])){
    
           $sql = "DELETE FROM demande_emploi WHERE id_utilisateur='" . $_GET["refuse"] . "'";
if (mysqli_query($con, $sql)) {
  header("location: dashboard_pers_morale.php?success=1");
} else {
    echo "Error deleting record: " . mysqli_error($con);

            
}
}	

	
$auth = "SELECT * FROM  personne_morale where (id_persmorale='".$_SESSION['id_per']."')";
$psw2=mysqli_query($con,$auth);
{
	while($res2=mysqli_fetch_array($psw2)) {
	$nomut=$res2[3];
	$prenomut=$res2[4];	
	
?>
<html lang="en">

<head>

<!-- Basic Page Needs
================================================== -->
<title>IJA EKDEM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">

<!-- Header Container
================================================== -->
<header id="header-container" class="fullwidth dashboard-header not-sticky">

	<!-- Header -->
	<div id="header">
		<div class="container">
			
			<!-- Left Side Content -->
			<div class="left-side">
				
				<!-- Logo -->
				<div id="logo">
					<a href="index-2.html"><img src="images/logo.png" alt=""></a>
				</div>

				<!-- Main Navigation -->
				<nav id="navigation">
					<ul id="responsive">

						<li><a href="#">Acceuil</a>
							<ul class="dropdown-nav">
								<li><a href="index.php"> Acceuil</a></li>
							</ul>
						</li>
						<li><a href="#" class="current">Tableau de bord</a>
							<ul class="dropdown-nav">
								<li><a href="dashboard.html">Tableau de bord</a></li>
								<li><a href="jobs-list-layout.php">Gérer les offres</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-post-a-job.php"> Publier un offre</a></li>
										<li><a href="jobs-list-layout.php"> Consulter la liste des offres</a></li>
										
									
									</ul>
								</li>
								<li><a href="dashboard-manage-candidates.php">Gérer la liste des condidatures</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-manage-candidates.php">Consulter mes listes</li>
                                         <li><a href="find_profile.php">Rechercher un profils </li>											
									</ul>
								</li>
							<a href="dashboard-settings.php">Paramètres</a>
							</ul>
						</li>
					</ul>
				</nav>
				<div class="clearfix"></div>
				<!-- Main Navigation / End -->
				
			</div>
			<!-- Left Side Content / End -->


			<!-- Right Side Content / End -->
			<div class="right-side">

	            <!--  User Notifications / End -->

				<!-- User Menu -->
				<div class="header-widget">

					<!-- Messages -->
					<div class="header-notifications user-menu">
						<div class="header-notifications-trigger">
							<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
						</div>

						<!-- Dropdown -->
						<div class="header-notifications-dropdown">

							<!-- User Status -->
							<div class="user-status">

								<!-- User Name / Avatar -->
								<div class="user-details">
									<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
									<div class="user-name">
									<?= 
$res2[3] ?> <?= 
$res2[2] ;}}?>  <span>Employeur</span>
									</div>
								</div>
								
								<!-- User Status Switcher -->
								<div class="status-switch" id="snackbar-user-status">
									<label class="user-online current-status">Online</label>
									<label class="user-invisible">Invisible</label>
									<!-- Status Indicator -->
									<span class="status-indicator" aria-hidden="true"></span>
								</div>	
						</div>
						
						<ul class="user-menu-small-nav">
							<li><a href="dashboard_pers_morale.php"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Logout</li>
						</ul>

						</div>
					</div>

				</div>
				<!-- User Menu / End -->

				<!-- Mobile Navigation Button -->
				<span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

			</div>
			<!-- Right Side Content / End -->

		</div>
	</div>
	<!-- Header / End -->

</header>
<div class="clearfix"></div>
<!-- Header Container / End -->


<!-- Dashboard Container -->
<div class="dashboard-container">

	<!-- Dashboard Sidebar
	================================================== -->
	<div class="dashboard-sidebar">
		<div class="dashboard-sidebar-inner" data-simplebar>
			<div class="dashboard-nav-container">

				<!-- Responsive Navigation Trigger -->
				<a href="#" class="dashboard-responsive-nav-trigger">
					<span class="hamburger hamburger--collapse" >
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</span>
					<span class="trigger-title">Dashboard Navigation</span>
				</a>
				
				<!-- Navigation -->
				<div class="dashboard-nav">
					<div class="dashboard-nav-inner">
						<ul data-submenu-title="Manage Accounts">
							<li><a href="#"><i class="icon-material-outline-business-center"></i> Gérer les offres</a>
								<ul>
									<li><a href="dashboard-post-a-job.php">Publier un offre </a></li>
									<li><a href="jobs-list-layout.php">Consulter la liste des offres </a></li>
								
								

								</ul>	
							</li>
							<li><a href="#"><i class="icon-material-outline-assignment"></i> Gérer la liste des  condidatures</a>
								<ul>
									<li><a href="condidat_list.php">Consulter mes listes </a></li>
								</ul>		
							</li>
							
							<li><a href="find_profile.php"><i class=""></i> Rechercher un profils</a>
								
							</li>
						</ul>

						<ul data-submenu-title="Mon Compte">
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Déconnexion</a></li>
						</ul>
						
					</div>
				</div>
				<!-- Navigation / End -->

			</div>
		</div>
	</div>
	<!-- Dashboard Sidebar / End -->

	<!-- Dashboard Content
	================================================== -->
	<div class="dashboard-content-container" data-simplebar>
		<div class="dashboard-content-inner" >
			
			<!-- Dashboard Headline -->
			<div class="dashboard-headline">
				<h3>Gérer les demandes de condidatures</h3>
				<span class="margin-top-7">Job Applications for <a href="#">Full Stack PHP Developer</a></span>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs" class="dark">
					<ul>
						<li><a href="#">Home</a></li>
						<li><a href="#">Dashboard</a></li>
						<li>Manage Candidates</li>
					</ul>
				</nav>
			</div>

			<!-- Row -->
			<div class='row'>

				<!-- Dashboard Box -->
				<div class='col-xl-12'>
					<div class='dashboard-box margin-top-0'>
					<div class='headline'>
<?php 
$_SESSION['id_off']=$_GET['id'];

// nombre de condidats en attente
 
//affichage de liste de condidature selon l'offre choisit
						
$result=" select * from utilisateur u ,demande_emploi d, offre_emploi o, personne_morale AS p where (u.id_utilisateur=d.id_utilisateur)  and (d.id_offreemploi='". $_GET['id'] ."') and 
(o.id_offreemploi=d.id_offreemploi) and (o.id_permorale=p.id_persmorale) and (p.id_persmorale='". $_SESSION['id_per']."' )";
$psw1=mysqli_query($con,$result);
		
  while($res=mysqli_fetch_array($psw1)) {
	  $pwid=$res[0];
	  $pw=$res[1];
	  $pw1=$res[2];
	  $pw2=$res[3];
	  $pw3=$res[4];
	  $pw4=$res[6];
	  $pw5=$res[7];
	  $pw6=$res[8];
	  $pw7=$res[9];
	  $id_dem=$res['id_demandeemp'];
	  echo $id_dem;
  

									

	echo"

						<div class='content'>
	
	   <ul class='dashboard-box-list'>
								<li>
									<form method='post'>
									<div class='freelancer-overview manage-candidates'>
										<div class='freelancer-overview-inner'>

											<!-- Avatar -->
											<div class='freelancer-avatar'>
												<div class='verified-badge'></div>
												<a href='#'><img src='images/user-avatar-big-03.jpg' alt=''></a>
											</div>

											<!-- Name -->
											<div class='freelancer-name'>
											    <h4><a href='#'><span class='freelancer-detail-item'><i class='icon-material-outline-description'> $pw</i></span></a></h4>
												<h4><a href='#'><span class='freelancer-detail-item'><i class='icon-material-outline-assignment'> $pw1 &nbsp $pw2</i></span></a></h4>

												<!-- Details -->
												<span class='freelancer-detail-item'><a href='#'><i class='icon-feather-mail'>$pw3</i> </a></span>
												<span class='freelancer-detail-item'><i class='icon-feather-phone'> $pw5 </i> </span>

												<!-- Rating -->
												<div class='freelancer-rating'>
													<div class='icon-material-outline-add-location'>$pw4</div>
													<div class='icon-material-outline-date-range'>$pw6</div>
												</div>
												

												<!-- Buttons -->
												<div class='buttons-to-right always-visible margin-top-25 margin-bottom-5'>
								
													<a href='dashboard-manage-candidates?refuse=$pwid' class=' button red ripple-effect'><i class='icon-feather-trash-2'></i> Refuser condidature</a>
                                                   
												
									</form></br>
									<form action='../Utilisateur/accepter.php' method='post'>
									<input type='submit' name='Accepter condidature' value='Accepter condidature' class=' button blue ripple-effect '> 
			
									</form>
									</div>
									</div>
								</div>
							</div>
								</li>
							</ul>
							</div>";}
?>
					
					</div>
				</div>

			</div>
			<!-- Row / End -->

			<!-- Footer -->
			<div class="dashboard-footer-spacer"></div>
			<div class="small-footer margin-top-15">
				<div class="small-footer-copyrights">
					© 2019 <strong>Hireo</strong>. All Rights Reserved.
				</div>
				<ul class="footer-social-links">
					<li>
						<a href="#" title="Facebook" data-tippy-placement="top">
							<i class="icon-brand-facebook-f"></i>
						</a>
					</li>
					<li>
						<a href="#" title="Twitter" data-tippy-placement="top">
							<i class="icon-brand-twitter"></i>
						</a>
					</li>
					<li>
						<a href="#" title="Google Plus" data-tippy-placement="top">
							<i class="icon-brand-google-plus-g"></i>
						</a>
					</li>
					<li>
						<a href="#" title="LinkedIn" data-tippy-placement="top">
							<i class="icon-brand-linkedin-in"></i>
						</a>
					</li>
				</ul>
				<div class="clearfix"></div>
			</div>
			<!-- Footer / End -->

		</div>
	</div>
	<!-- Dashboard Content / End -->

</div>
<!-- Dashboard Container / End -->

</div>
<!-- Wrapper / End -->


<!-- Send Direct Message Popup
================================================== -->
<div id="small-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">

	<!--Tabs -->
	<div class="sign-in-form">

		<ul class="popup-tabs-nav">
			<li><a href="#tab">Send Message</a></li>
		</ul>

		<div class="popup-tabs-container">

			<!-- Tab -->
			<div class="popup-tab-content" id="tab">
				
				<!-- Welcome Text -->
				<div class="welcome-text">
					<h3>Direct Message To Sindy</h3>
				</div>
					
				<!-- Form -->
				<form method="post" id="send-pm">
					<textarea name="textarea" cols="10" placeholder="Message" class="with-border" required></textarea>
				</form>
				
				<!-- Button -->
				<button class="button full-width button-sliding-icon ripple-effect" type="submit" form="send-pm">Send <i class="icon-material-outline-arrow-right-alt"></i></button>

			</div>

		</div>
	</div>
</div>
<!-- Send Direct Message Popup / End -->


<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 
</script>

</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-manage-candidates.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:08 GMT -->
</html>