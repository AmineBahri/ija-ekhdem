<?php
session_start();
if(isset($_SESSION["id_per"])){ unset($_SESSION["id_per"]);}
session_destroy();
header("location: ../index.php"); 
?>