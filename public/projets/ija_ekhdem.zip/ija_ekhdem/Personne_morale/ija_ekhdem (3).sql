-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 03 nov. 2020 à 18:53
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ija_ekhdem`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(8) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin@admin');

-- --------------------------------------------------------

--
-- Structure de la table `connaissance_linguistiques`
--

DROP TABLE IF EXISTS `connaissance_linguistiques`;
CREATE TABLE IF NOT EXISTS `connaissance_linguistiques` (
  `id_conling` int(8) NOT NULL AUTO_INCREMENT,
  `langue_parlee` varchar(255) NOT NULL,
  `niveau_langue` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_conling`),
  KEY `id_demandeemp` (`id_demandeemp`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `connaissance_linguistiques`
--

INSERT INTO `connaissance_linguistiques` (`id_conling`, `langue_parlee`, `niveau_langue`, `id_demandeemp`) VALUES
(99, 'ENG', 'Débutant', 32),
(98, 'AR', 'Débutant', 32),
(97, 'FR', 'Débutant', 32),
(96, 'AR', 'Débutant', 34),
(95, 'AR', 'Débutant', 90),
(94, '', '', 87),
(93, 'AR', 'Débutant', 87),
(92, '', '', 86),
(91, 'AR', 'Débutant', 86),
(90, 'hgg', 'juhj', 85),
(89, 'AR', 'Débutant', 85),
(50, 'juu', 'jdhiqsz', 64),
(51, 'CH', 'Débutant', 65),
(52, 'juu', 'jdhiqsz', 65),
(53, 'FR', 'Débutant', 66),
(54, 'hjfgf', 'ggg', 66),
(55, 'FR', 'Débutant', 67),
(56, 'hjfgf', 'ggg', 67),
(57, 'FR', 'Débutant', 68),
(58, 'hjfgf', 'ggg', 68),
(59, 'FR', 'Débutant', 69),
(60, 'hjfgf', 'ggg', 69),
(61, 'FR', 'Débutant', 70),
(62, 'hjfgf', 'ggg', 70),
(63, 'FR', 'Débutant', 71),
(64, 'hjfgf', 'ggg', 71),
(65, 'FR', 'Débutant', 0),
(66, 'hjfgf', 'ggg', 0),
(67, 'FR', 'Débutant', 74),
(68, 'hjfgf', 'ggg', 74),
(69, 'FR', 'Débutant', 75),
(70, 'hjfgf', 'ggg', 75),
(71, 'HI', 'Débutant', 76),
(72, 'hgg', 'gggg', 76),
(73, 'HI', 'Débutant', 77),
(74, 'hgg', 'gggg', 77),
(75, 'HI', 'Débutant', 78),
(76, 'hgg', 'gggg', 78),
(77, 'HI', 'Débutant', 79),
(78, 'hgg', 'gggg', 79),
(79, 'HI', 'Débutant', 80),
(80, 'hgg', 'gggg', 80),
(81, 'AR', 'Débutant', 81),
(82, '', '', 81),
(83, 'AR', 'Débutant', 82),
(84, 'hgg', 'juhj', 82),
(85, 'AR', 'Débutant', 83),
(86, 'hgg', 'juhj', 83),
(87, 'AR', 'Débutant', 84),
(88, 'hgg', 'juhj', 84);

-- --------------------------------------------------------

--
-- Structure de la table `con_informatique`
--

DROP TABLE IF EXISTS `con_informatique`;
CREATE TABLE IF NOT EXISTS `con_informatique` (
  `id_coninf` int(11) NOT NULL AUTO_INCREMENT,
  `description_logiciel` varchar(255) NOT NULL,
  `syst_exploitation` varchar(255) NOT NULL,
  `autre_info` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_coninf`),
  KEY `id_demandeemp` (`id_demandeemp`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `con_informatique`
--

INSERT INTO `con_informatique` (`id_coninf`, `description_logiciel`, `syst_exploitation`, `autre_info`, `id_demandeemp`) VALUES
(10, '', '', '', 3),
(9, 'jjj', 'hjghgh', 'gggg', 32),
(8, 'djdj', 'kkkkkkkkkkkk', 'yhhbh', 32),
(7, 'jfh', 'jeeh', 'jhui', 85),
(11, 'jjj', 'hjghgh', 'gggg', 87),
(12, '', '', '', 87),
(13, 'jjj', 'hjghgh', 'gggg', 93),
(14, 'jjj', 'hjghgh', 'gggg', 94),
(15, 'djdj', 'kkkkkkkkkkkk', 'yhhbh', 95);

-- --------------------------------------------------------

--
-- Structure de la table `demande_emploi`
--

DROP TABLE IF EXISTS `demande_emploi`;
CREATE TABLE IF NOT EXISTS `demande_emploi` (
  `id_demandeemp` int(8) NOT NULL AUTO_INCREMENT,
  `date_demande` date NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_offreemploi` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_demandeemp`),
  KEY `id_utilisateur` (`id_utilisateur`),
  KEY `id_offreemploi` (`id_offreemploi`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `demande_emploi1`
--

DROP TABLE IF EXISTS `demande_emploi1`;
CREATE TABLE IF NOT EXISTS `demande_emploi1` (
  `id_demandeemp` int(8) NOT NULL AUTO_INCREMENT,
  `date_demande` date NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_offreemploi` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_demandeemp`),
  KEY `id_utilisateur` (`id_utilisateur`),
  KEY `id_offreemploi` (`id_offreemploi`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `demande_emploi1`
--

INSERT INTO `demande_emploi1` (`id_demandeemp`, `date_demande`, `id_utilisateur`, `id_offreemploi`) VALUES
(41, '2020-11-02', 4, 16),
(40, '2020-11-02', 4, 16),
(39, '2020-11-02', 4, 16),
(38, '2020-11-02', 4, 18),
(37, '2020-11-02', 4, 16),
(47, '2020-11-02', 4, 16),
(46, '2020-11-02', 2, 19),
(36, '2020-11-02', 4, 18),
(32, '2020-11-01', 4, 16),
(33, '2020-11-01', 2, 18),
(42, '2020-11-02', 4, 16),
(43, '2020-11-02', 4, 16),
(44, '2020-11-02', 4, 16),
(48, '2020-11-02', 4, 16),
(49, '2020-11-02', 4, 16),
(50, '2020-11-02', 4, 16);

-- --------------------------------------------------------

--
-- Structure de la table `diplome`
--

DROP TABLE IF EXISTS `diplome`;
CREATE TABLE IF NOT EXISTS `diplome` (
  `id_diplome` int(8) NOT NULL AUTO_INCREMENT,
  `annee_obtention` date NOT NULL,
  `mention` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  `specialite` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_diplome`),
  KEY `id_demandeemp` (`id_demandeemp`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `diplome`
--

INSERT INTO `diplome` (`id_diplome`, `annee_obtention`, `mention`, `id_demandeemp`, `specialite`) VALUES
(1, '2020-10-07', 'bien', 32, 'developpement de système d\'information'),
(2, '2020-10-10', 'jjj', 32, 'aaaaaaaaaaaa'),
(3, '2020-10-17', 'jkhg', 73, NULL),
(4, '2020-11-05', 'hd', 83, NULL),
(5, '2020-11-05', 'hd', 84, NULL),
(6, '2020-11-05', 'hd', 85, NULL),
(7, '2020-10-29', 'dff', 86, NULL),
(8, '2020-10-29', 'dff', 87, NULL),
(9, '2020-10-29', 'dff', 93, NULL),
(10, '2020-10-29', 'dff', 94, NULL),
(11, '2020-11-05', 'dff', 95, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `experience_professionnelle`
--

DROP TABLE IF EXISTS `experience_professionnelle`;
CREATE TABLE IF NOT EXISTS `experience_professionnelle` (
  `id_expprof` int(8) NOT NULL AUTO_INCREMENT,
  `poste_occupe` varchar(255) NOT NULL,
  `lieu_experience` varchar(255) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_expprof`),
  KEY `id_demandeemp` (`id_demandeemp`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `experience_professionnelle`
--

INSERT INTO `experience_professionnelle` (`id_expprof`, `poste_occupe`, `lieu_experience`, `date_debut`, `date_fin`, `id_demandeemp`) VALUES
(39, 'poste occupé', 'lieu expérience', '2020-11-25', '2020-11-08', 32),
(38, 'poste occupé', 'lieu expérience', '2020-11-27', '2020-11-12', 94),
(37, 'poste occupé', 'lieu expérience', '2020-11-27', '2020-11-12', 93),
(36, '', '', '0000-00-00', '0000-00-00', 87),
(35, 'poste occupé', 'lieu expérience', '2020-11-27', '2020-11-12', 87),
(34, '', '', '0000-00-00', '0000-00-00', 86),
(33, 'poste occupé', 'lieu expérience', '2020-11-27', '2020-11-12', 86),
(32, 'ddd', 'dhbh', '2020-11-14', '2020-11-14', 85),
(31, 'poste occupé', 'lieu expérience', '2020-11-14', '2020-11-05', 85);

-- --------------------------------------------------------

--
-- Structure de la table `formations`
--

DROP TABLE IF EXISTS `formations`;
CREATE TABLE IF NOT EXISTS `formations` (
  `id_formations` int(8) NOT NULL AUTO_INCREMENT,
  `diplome` varchar(255) NOT NULL,
  `lieu_formation` varchar(255) NOT NULL,
  `duree_formation` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_formations`),
  KEY `id_demandeemp` (`id_demandeemp`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formations`
--

INSERT INTO `formations` (`id_formations`, `diplome`, `lieu_formation`, `duree_formation`, `id_demandeemp`) VALUES
(47, 'nesrine walha', 'hhhj', 'hhh', 32),
(46, 'nesrine walha', 'dddd', 'jejj', 32),
(44, '', '', '', 87),
(45, 'nesrine walha', 'dddd', 'jejj', 93),
(43, 'nesrine walha', 'dddd', 'jejj', 87),
(42, '', '', '', 86),
(41, 'nesrine walha', 'dddd', 'jejj', 86),
(40, 'nesrine walha', 'hhhj', 'hhh', 85),
(39, 'nesrine walha', 'ffff', 'jejj', 85);

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `id_notification` int(8) NOT NULL AUTO_INCREMENT,
  `cont_notification` text COLLATE utf8_estonian_ci NOT NULL,
  `id_utilisateur` int(8) NOT NULL,
  `id_persmorale` int(8) NOT NULL,
  PRIMARY KEY (`id_notification`),
  KEY `id_utilisateur` (`id_utilisateur`,`id_persmorale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

-- --------------------------------------------------------

--
-- Structure de la table `offre_emploi`
--

DROP TABLE IF EXISTS `offre_emploi`;
CREATE TABLE IF NOT EXISTS `offre_emploi` (
  `id_offreemploi` int(8) NOT NULL AUTO_INCREMENT,
  `titre_offre` varchar(255) NOT NULL,
  `type_offre` varchar(255) NOT NULL,
  `equipe` varchar(255) NOT NULL,
  `categorie_offre` varchar(255) NOT NULL,
  `emplacement` varchar(255) NOT NULL,
  `salaire_min` varchar(255) NOT NULL,
  `salaire_max` varchar(255) NOT NULL,
  `nombre_poste` varchar(255) NOT NULL,
  `durée` varchar(255) NOT NULL,
  `date_publication` varchar(255) NOT NULL,
  `description_offre` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_permorale` int(8) DEFAULT NULL,
  PRIMARY KEY (`id_offreemploi`),
  KEY `id_utilisateur` (`id_utilisateur`),
  KEY `id_permorale` (`id_permorale`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `offre_emploi`
--

INSERT INTO `offre_emploi` (`id_offreemploi`, `titre_offre`, `type_offre`, `equipe`, `categorie_offre`, `emplacement`, `salaire_min`, `salaire_max`, `nombre_poste`, `durée`, `date_publication`, `description_offre`, `image`, `id_utilisateur`, `id_permorale`) VALUES
(16, 'Charge Recherche & DÃ©veloppement', 'Ã€ plein temps', 'MobiSM', 'ComptabilitÃ© et finance', 'El manzah 6 tunis', '600', '700', '3', '4jours', '2020-10-30', 'azertyuiop\r\nmlkjhgfdsq\r\nwxcvbn,;', 'neoxam.png', 4, 11),
(19, '3WWIT recrute 2 DÃ©veloppeurs Web', 'Ã€ plein temps', 'MobiSM', 'ComptabilitÃ© et finance', 'aaaaaaa', '00', '600', '3', '3 jours', '2020-11-04', 'aaaaaaaa', 'neoxam.png', NULL, 11);

-- --------------------------------------------------------

--
-- Structure de la table `personne_morale`
--

DROP TABLE IF EXISTS `personne_morale`;
CREATE TABLE IF NOT EXISTS `personne_morale` (
  `id_persmorale` int(8) NOT NULL AUTO_INCREMENT,
  `cin` int(8) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `nom_societe` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL,
  `domaine` varchar(255) NOT NULL,
  PRIMARY KEY (`id_persmorale`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personne_morale`
--

INSERT INTO `personne_morale` (`id_persmorale`, `cin`, `nom`, `prenom`, `nom_societe`, `email`, `password`, `adresse`, `telephone`, `date_naissance`, `domaine`) VALUES
(7, 101010101, 'dhia', 'hannachi', 'MobiSm', 'dhia@gmail.com', 'dhia1234', 'Avenue HAbib bourguiba jendouba8100', '123555555', '2020-10-23', 'developpementt'),
(9, 11111111, 'Mohamed', 'abidi', 'MobiSmm', 'mohamed@gmail.com', 'mohamed', 'Avenue HAbib bourguiba tunis', '23445666', '2020-10-14', 'developpementt'),
(8, 0, 'meriem', 'abidi', 'MobiSmm', 'meriem@gmail.com', '123456789', 'Avenue HAbib bourguiba tunis', '1111111111', '2020-10-30', 'developpementt'),
(10, 0, 'meriem', 'khemiri', 'MobiSm', 'meriem@gmail.com', 'meriem1234', 'el manzah 6 tunis', '00000000', '2020-10-29', 'developpement'),
(11, 0, 'test1', 'st1', 'test', 'test@gmail.com', '1234', 'test', '1111111111', '2020-10-29', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

DROP TABLE IF EXISTS `projet`;
CREATE TABLE IF NOT EXISTS `projet` (
  `id_projet` int(8) NOT NULL AUTO_INCREMENT,
  `nom_projet` varchar(30) COLLATE utf8_estonian_ci NOT NULL,
  `cont_projet` text COLLATE utf8_estonian_ci NOT NULL,
  `id_utilisateur` int(8) NOT NULL,
  `id_persmorale` int(8) NOT NULL,
  PRIMARY KEY (`id_projet`),
  KEY `id_utilisateur` (`id_utilisateur`,`id_persmorale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_utilisateur` int(8) NOT NULL AUTO_INCREMENT,
  `cin` int(8) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `cin`, `nom`, `prenom`, `email`, `password`, `adresse`, `telephone`, `date_naissance`) VALUES
(1, 12345678, 'henda', 'ilhem', 'admin@gmail.com', '123456789', 'avenue habib bourguiba jendouba', '23468853', '2020-07-31'),
(2, 123456789, 'dhia', 'hannachi', 'bb@gmail.com', '123456789', 'aaaaaaaaaaaaanjkk', '123456789', '2020-08-18'),
(4, 1010101, 'henda', 'ilhem', 'ilhembenhenda23@gmail.com', 'ilhem2020', 'avenue habib bourguiba jendouba', '23468853', '2020-10-07');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
