<?php  
  include("db.php");
    if(isset($_POST['email']) && isset($_POST['password']) && isset($_POST["account-type-radio"])){
		
        $email = $_POST['email'];  
		$password = $_POST['password'];
        $radioVal = $_POST["account-type-radio"];		
		  if($radioVal == "freelance"){
			 $result=mysqli_query($con,"SELECT * FROM utilisateur    WHERE email = '$email' AND password = '$password'  ");			
			 
                        while($res=mysqli_fetch_array($result)) {
							$id_per=$res['id_utilisateur'];
						 if ($result == 0  )
		      	            $erreur="1"; 
			  
						 else {
							 session_start();
							$_SESSION["id_per"] = $id_per;
							 header("location: dashboard-post-a-job.php?success=1"); }}
		   
		 }else  if($radioVal == "employeur")
		 {
			 $result=mysqli_query($con,"SELECT * FROM personne_morale   WHERE email = '$email' AND password = '$password'  ");
                  
	          while(
			  $res=mysqli_fetch_array($result)) {
							$id_per=$res['id_persmorale'];
						 if ($result == 0  )
						 
		      	            $erreur="1"; 
						
			  
						 else {
							 session_start();
							$_SESSION["id_per"] = $id_per;
							 header("location: dashboard_pers_morale.php?success=1"); }}

}  
	}	
?>