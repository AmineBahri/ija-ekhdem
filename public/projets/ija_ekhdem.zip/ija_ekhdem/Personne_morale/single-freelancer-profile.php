<?php
session_start();
include("db.php");
	
$auth = "SELECT * FROM  personne_morale where (id_persmorale='".$_SESSION['id_per']."')";
$psw2=mysqli_query($con,$auth);
{
	while($res2=mysqli_fetch_array($psw2)) {
	$nomut=$res2[3];
	$prenomut=$res2[4];
?>
<html lang="en">

<head>

<!-- Basic Page Needs
================================================== -->
<title>IJA EKDEM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">

<!-- Header Container
================================================== -->
<header id="header-container" class="fullwidth dashboard-header not-sticky">

	<!-- Header -->
	<div id="header">
		<div class="container">
			
			<!-- Left Side Content -->
			<div class="left-side">
				
				<!-- Logo -->
				<div id="logo">
					<a href="index-2.html"><img src="images/logo.png" alt=""></a>
				</div>

				<!-- Main Navigation -->
				<nav id="navigation">
					<ul id="responsive">

						<li><a href="#">Acceuil</a>
							<ul class="dropdown-nav">
								<li><a href="index-4.html"> Acceuil</a></li>
							</ul>
						</li>
						<li><a href="#" class="current">Tableau de bord</a>
							<ul class="dropdown-nav">
								<li><a href="dashboard.html">Tableau de bord</a></li>
								<li><a href="jobs-list-layout.php">Gérer les offres</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-post-a-job.php"> Publier un offre</a></li>
										<li><a href="jobs-list-layout.php"> Consulter la liste des offres</a></li>
										
									
									</ul>
								</li>
								<li><a href="dashboard-manage-candidates.php">Gérer la liste des condidatures</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-manage-candidates.php">Consulter mes listes</li>
                                         <li><a href="find_profile.php">Rechercher un profils </li>											
									</ul>
								</li>
							<a href="dashboard-settings.php">Paramètres</a>
							</ul>
						</li>
					</ul>
				</nav>
				<div class="clearfix"></div>
				<!-- Main Navigation / End -->
				
			</div>
			<!-- Left Side Content / End -->


			<!-- Right Side Content / End -->
			<div class="right-side">

	            <!--  User Notifications / End -->

				<!-- User Menu -->
				<div class="header-widget">

					<!-- Messages -->
					<div class="header-notifications user-menu">
						<div class="header-notifications-trigger">
							<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
						</div>

						<!-- Dropdown -->
						<div class="header-notifications-dropdown">

							<!-- User Status -->
							<div class="user-status">

								<!-- User Name / Avatar -->
								<div class="user-details">
									<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
									<div class="user-name">
									<?= 
$res2[3] ?> <?= 
$res2[2] ;}}?>  <span>Employeur</span>
									</div>
								</div>
								
								<!-- User Status Switcher -->
								<div class="status-switch" id="snackbar-user-status">
									<label class="user-online current-status">Online</label>
									<label class="user-invisible">Invisible</label>
									<!-- Status Indicator -->
									<span class="status-indicator" aria-hidden="true"></span>
								</div>	
						</div>
						
						<ul class="user-menu-small-nav">
							<li><a href="dashboard_pers_morale.php"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Logout</li>
						</ul>

						</div>
					</div>

				</div>
				<!-- User Menu / End -->

				<!-- Mobile Navigation Button -->
				<span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

			</div>
			<!-- Right Side Content / End -->

		</div>
	</div>
	<!-- Header / End -->

</header>
<div class="clearfix"></div>
<!-- Header Container / End -->
<?php
$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 
while($row = mysqli_fetch_array($result)) {

			if($row[13] == $_GET["id"]   )
							    
					   { 
					   
					   
			$sql1 = "SELECT * FROM utilisateur where id_utilisateur='".$_GET["id"]."'";
			$psw=mysqli_query($con,$sql1);
 while($res=mysqli_fetch_array($psw)) {
	   $pw=$res['cin'];
	    $pw1=$res['nom'];
		$pw2=$res['prenom'];
		$pw3=$res['email'];
		$pw4=$res['adresse'];
		$pw5=$res['telephone'];
		$pw6=$res['date_naissance'];
 }  		
}}}
	 
	?> 					
						
<div class="single-page-header freelancer-header" data-background-image="images/single-freelancer.jpg">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="single-page-header-inner">
					<div class="left-side">
						<div class="header-image freelancer-avatar"><img src="images/user-avatar-big-02.jpg"></div>
						<div class="header-details">
							<h3><?php  echo $pw1 ;?> &nbsp;<?php  echo $pw2;?><span></span></h3>
							<ul>
								<li><div class="star-rating" data-rating="CIN"><?php  echo $pw ; ?></div></li><br>
						
								<li><div class="star-rating" data-rating="Email"><?php echo $pw3;?></div></li>
								<li><div class="star-rating" data-rating="Adresse"><?php echo $pw4; ?></div></li><br>
								<li><div class="star-rating" data-rating="Telephone"><?php echo $pw5;?></div></li>
								<li><div class="star-rating" data-rating="Date de naissance"><?php echo $pw6;?></div></li><br>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Page Content
================================================== -->
<div class="container">
	<div class="row">
		
		<!-- Content -->
		<div class="col-xl-8 col-lg-8 content-right-offset">
			
			<!-- Page Content -->
			<div class="single-page-section">
				<h3 class="margin-bottom-25">À propos de moi</h3>
				<!-- Container -->
<div class="container">
	<div class="row">

		<div class="col-xl-12">
			<div class="contact-location-info margin-bottom-50">
				<div class="contact-address">
					<ul>
						<li class="contact-address-headline">Diplome</li>
						
<?php 

$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 $i=0;
while($row = mysqli_fetch_array($result)) {

if($row[13] == $_GET["id"]   )
							    
 {
	 
$sql6 = "SELECT * FROM utilisateur AS U, demande_emploi1 AS D, diplome AS DI  WHERE (U.id_utilisateur=D.id_utilisateur) AND (U.id_utilisateur='". $_GET["id"] ."') AND (D.id_demandeemp=DI.id_demandeemp)";
 $psw6=mysqli_query($con,$sql6);
 while($res6=mysqli_fetch_array($psw6)) {
	 $dip1=$res6['annee_obtention'];
	 $dip2=$res6['mention'];
	 $dip3=$res6['specialite'];
 

	 
	 
	 echo"
						<li>Diplome obtenue en :$dip3  $dip1 </li>
					
						<a href='#'>avec  mention  $dip2 </a>
";}}}}
						?>
					</ul>

				</div>
			</div>
        </div>
	</div>
</div>
<div class='container'>
	<div class='row'>

		<div class='col-xl-12'>
			<div class='contact-location-info margin-bottom-50'>
				<div class='contact-address'>
					<ul>
						<li class='contact-address-headline'>Formation</li>

<?php 

$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 $i=0;
while($row = mysqli_fetch_array($result)) {

if($row[13] == $_GET["id"]   )
							    
 {
$sql7 = "SELECT * FROM utilisateur AS U, demande_emploi1 AS D, formations AS F  WHERE (U.id_utilisateur=D.id_utilisateur) AND (U.id_utilisateur='". $_GET["id"] ."') AND (D.id_demandeemp=F.id_demandeemp)";
 $psw7=mysqli_query($con,$sql7);
 while($res7=mysqli_fetch_array($psw7)) {
	   $F1=$res7['diplome'];
	   $F2=$res7['lieu_formation'];
	   $F3=$res7['duree_formation'];
 
	 
	 
echo"				   
						<li>Diplome obtenue en : $F1 en  $F2 </li>
 <a href='#'>Durée  $F3 </a>";}
}}}
	?>					
					</ul>

				</div>
			</div>
        </div>
	</div>
</div>
<div class='container'>
	<div class='row'>

		<div class='col-xl-12'>
			<div class='contact-location-info margin-bottom-50'>
				<div class='contact-address'>
					<ul>
						<li class='contact-address-headline'>Connaissance informatique</li>
						
<?php						
$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 $i=0;
while($row = mysqli_fetch_array($result)) {

			if($row[13] == $_GET["id"]   )
							    
					   { 

$sql5 = "SELECT * FROM utilisateur AS U, demande_emploi1 AS D, con_informatique AS CO  WHERE (U.id_utilisateur=D.id_utilisateur) AND (U.id_utilisateur='". $_GET["id"] ."') AND (D.id_demandeemp=CO.id_demandeemp)";
 $psw5=mysqli_query($con,$sql5);
 while($res5=mysqli_fetch_array($psw5)) {
	  $CON1=$res5['description_logiciel'];
	  $CON2=$res5['syst_exploitation'];
	  $CON3=$res5['autre_info'];
 
					   
						
		echo"				
						<li>Diplome obtenue en :  $CON1  en $CON2 </li>
						<a href='#'>Durée $CON3</a>";
}}}}?>
					</ul>

				</div>
			</div>
        </div>
	</div>
</div>
<div class='container'>
	<div class='row'>

		<div class='col-xl-12'>
			<div class='contact-location-info margin-bottom-50'>
				<div class='contact-address'>
					<ul>
						<li class='contact-address-headline'>Connaissance Linguistique</li>
					<?php 
					$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 $i=0;
while($row = mysqli_fetch_array($result)) {

			if($row[13] == $_GET["id"]   )
							    
					   { 
		$sql4 = "SELECT * FROM utilisateur AS U, demande_emploi1 AS D, connaissance_linguistiques AS CL  WHERE (U.id_utilisateur=D.id_utilisateur) AND (U.id_utilisateur='". $_GET["id"] ."') AND (D.id_demandeemp=CL.id_demandeemp)";
 $psw4=mysqli_query($con,$sql4);
 while($res1=mysqli_fetch_array($psw4)) {
	   $CL1=$res1['langue_parlee'];
	   $CL2=$res1['niveau_langue'];
 
			
					
					
					
					echo"
					
						<li>Langue obtenue  :  $CL1 ====>  $CL2 </li>
";}}}}
						?>
						
					</ul>

				</div>
			</div>
        </div>
	</div>
</div>
			<!-- Boxed List -->
			<div class='boxed-list margin-bottom-60'>
				<div class='boxed-list-headline'>
					<h3><i class='icon-material-outline-thumb-up'></i> Historique de travail  </h3>
				</div>
				<ul class='boxed-list-ul'>
					
					<li>
						<div class='boxed-list-item'>
							<!-- Content -->
							<div class='item-content'>
								
								
<?php
$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 
while($row = mysqli_fetch_array($result)) {

			if($row[13] == $_GET["id"]   )
							    
					   { 
					   $titre=$row['titre_offre'];
					   $type=$row['type_offre'];
					   $categorie=$row['categorie_offre'];
					   $date=$row['date_publication'];
		echo"			           
                            		<h4>$titre <span>Classé comme $categorie</span></h4>
								   <div class='item-details margin-top-10'>
									<div class='star-rating' data-rating='Tpe de travail'>$type</div>
									<div class='detail-item'><i class='icon-material-outline-date-range'></i> $date</div>";
}}}?>
								</div>
								<div class='item-description'>
									<p> </p>
								</div>
							</div>
						</div>
					</li>
					
					
				</ul>

				<!-- Pagination -->
				<div class='clearfix'></div>
				<div class='pagination-container margin-top-40 margin-bottom-10'>
					<nav class='pagination'>
						<ul>
							<li><a href='#' class='ripple-effect current-page'>1</a></li>
							<li><a href='#' class='ripple-effect'>2</a></li>
							<li class='pagination-arrow'><a href='#' class='ripple-effect'><i class='icon-material-outline-keyboard-arrow-right'></i></a></li>
						</ul>
					</nav>
				</div>
				<div class='clearfix'></div>
				<!-- Pagination / End -->

			</div>
			<!-- Boxed List / End -->
			
			
		</div>

			</div>
		</div>

	</div>
</div>


<!-- Spacer -->
<div class="margin-top-15"></div>
<!-- Spacer / End-->

<!-- Footer
================================================== -->
<div id="footer">
	
	<!-- Footer Top Section -->
	<div class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">

					<!-- Footer Rows Container -->
					<div class="footer-rows-container">
						
						<!-- Left Side -->
						<div class="footer-rows-left">
							<div class="footer-row">
								<div class="footer-row-inner footer-logo">
									<img src="images/logo2.png" alt="">
								</div>
							</div>
						</div>
						
						<!-- Right Side -->
						<div class="footer-rows-right">

							<!-- Social Icons -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<ul class="footer-social-links">
										<li>
											<a href="#" title="Facebook" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-facebook-f"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Twitter" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-twitter"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Google Plus" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-google-plus-g"></i>
											</a>
										</li>
										<li>
											<a href="#" title="LinkedIn" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-linkedin-in"></i>
											</a>
										</li>
									</ul>
									<div class="clearfix"></div>
								</div>
							</div>
							
							<!-- Language Switcher -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<select class="selectpicker language-switcher" data-selected-text-format="count" data-size="5">
										<option selected>English</option>
										<option>Français</option>
										<option>Español</option>
										<option>Deutsch</option>
									</select>
								</div>
							</div>
						</div>

					</div>
					<!-- Footer Rows Container / End -->
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Top Section / End -->

	<!-- Footer Middle Section -->
	<div class="footer-middle-section">
		<div class="container">
			<div class="row">

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>For Candidates</h3>
						<ul>
							<li><a href="#"><span>Browse Jobs</span></a></li>
							<li><a href="#"><span>Add Resume</span></a></li>
							<li><a href="#"><span>Job Alerts</span></a></li>
							<li><a href="#"><span>My Bookmarks</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>For Employers</h3>
						<ul>
							<li><a href="#"><span>Browse Candidates</span></a></li>
							<li><a href="#"><span>Post a Job</span></a></li>
							<li><a href="#"><span>Post a Task</span></a></li>
							<li><a href="#"><span>Plans & Pricing</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Helpful Links</h3>
						<ul>
							<li><a href="#"><span>Contact</span></a></li>
							<li><a href="#"><span>Privacy Policy</span></a></li>
							<li><a href="#"><span>Terms of Use</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Account</h3>
						<ul>
							<li><a href="#"><span>Log In</span></a></li>
							<li><a href="#"><span>My Account</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Newsletter -->
				<div class="col-xl-4 col-lg-4 col-md-12">
					<h3><i class="icon-feather-mail"></i> Sign Up For a Newsletter</h3>
					<p>Weekly breaking news, analysis and cutting edge advices on job searching.</p>
					<form action="#" method="get" class="newsletter">
						<input type="text" name="fname" placeholder="Enter your email address">
						<button type="submit"><i class="icon-feather-arrow-right"></i></button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Middle Section / End -->
	
	<!-- Footer Copyrights -->
	<div class="footer-bottom-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">
					© 2019 <strong>Hireo</strong>. All Rights Reserved.
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Copyrights / End -->

</div>
<!-- Footer / End -->

</div>
<!-- Wrapper / End -->


<!-- Make an Offer Popup
================================================== -->
<div id="small-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">

	<!--Tabs -->
	<div class="sign-in-form">

		<ul class="popup-tabs-nav">
			<li><a href="#tab">Make an Offer</a></li>
		</ul>

		<div class="popup-tabs-container">

			<!-- Tab -->
			<div class="popup-tab-content" id="tab">
				
				<!-- Welcome Text -->
				<div class="welcome-text">
					<h3>Discuss your project with David</h3>
				</div>
					
				<!-- Form -->
				<form method="post">

					<div class="input-with-icon-left">
						<i class="icon-material-outline-account-circle"></i>
						<input type="text" class="input-text with-border" name="name" id="name" placeholder="First and Last Name"/>
					</div>

					<div class="input-with-icon-left">
						<i class="icon-material-baseline-mail-outline"></i>
						<input type="text" class="input-text with-border" name="emailaddress" id="emailaddress" placeholder="Email Address"/>
					</div>

					<textarea name="textarea" cols="10" placeholder="Message" class="with-border"></textarea>

					<div class="uploadButton margin-top-25">
						<input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="upload" multiple/>
						<label class="uploadButton-button ripple-effect" for="upload">Add Attachments</label>
						<span class="uploadButton-file-name">Allowed file types: zip, pdf, png, jpg <br> Max. files size: 50 MB.</span>
					</div>

				</form>
				
				<!-- Button -->
				<button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit">Make an Offer <i class="icon-material-outline-arrow-right-alt"></i></button>

			</div>
			<!-- Login -->
			<div class="popup-tab-content" id="loginn">
				
				<!-- Welcome Text -->
				<div class="welcome-text">
					<h3>Discuss Your Project With Tom</h3>
				</div>
					
				<!-- Form -->
				<form method="post" id="make-an-offer-form">

					<div class="input-with-icon-left">
						<i class="icon-material-outline-account-circle"></i>
						<input type="text" class="input-text with-border" name="name2" id="name2" placeholder="First and Last Name" required/>
					</div>

					<div class="input-with-icon-left">
						<i class="icon-material-baseline-mail-outline"></i>
						<input type="text" class="input-text with-border" name="emailaddress2" id="emailaddress2" placeholder="Email Address" required/>
					</div>

					<textarea name="textarea" cols="10" placeholder="Message" class="with-border"></textarea>

					<div class="uploadButton margin-top-25">
						<input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="upload-cv" multiple/>
						<label class="uploadButton-button" for="upload-cv">Add Attachments</label>
						<span class="uploadButton-file-name">Allowed file types: zip, pdf, png, jpg <br> Max. files size: 50 MB.</span>
					</div>

				</form>
				
				<!-- Button -->
				<button class="button full-width button-sliding-icon ripple-effect" type="submit" form="make-an-offer-form">Make an Offer <i class="icon-material-outline-arrow-right-alt"></i></button>

			</div>

		</div>
	</div>
</div>
<!-- Make an Offer Popup / End -->



<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 

// Snackbar for "place a bid" button
$('#snackbar-place-bid').click(function() { 
	Snackbar.show({
		text: 'Your bid has been placed!',
	}); 
}); 


// Snackbar for copy to clipboard button
$('.copy-url-button').click(function() { 
	Snackbar.show({
		text: 'Copied to clipboard!',
	}); 
}); 
</script>

</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/single-freelancer-profile.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:00 GMT -->
</html>