<?php
session_start();
include("db.php");

$auth = "SELECT * FROM  personne_morale where (id_persmorale='".$_SESSION['id_per']."')";
$psw2=mysqli_query($con,$auth);
{
	while($res2=mysqli_fetch_array($psw2)) {
	$nomut=$res2[3];
	$prenomut=$res2[4];
   
?>
<html lang="en">

<head>

<!-- Basic Page Needs
================================================== -->
<title>IJA EKDEM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">

<!-- Header Container
================================================== -->
<header id="header-container" class="fullwidth dashboard-header not-sticky">

	<!-- Header -->
	<div id="header">
		<div class="container">
			
			<!-- Left Side Content -->
			<div class="left-side">
				
				<!-- Logo -->
				<div id="logo">
					<a href="index-2.html"><img src="images/logo.png" alt=""></a>
				</div>

				<!-- Main Navigation -->
				<nav id="navigation">
					<ul id="responsive">

						<li><a href="#">Acceuil</a>
							<ul class="dropdown-nav">
								<li><a href="index-4.html"> Acceuil</a></li>
							</ul>
						</li>
						<li><a href="#" class="current">Tableau de bord</a>
							<ul class="dropdown-nav">
								<li><a href="dashboard.html">Tableau de bord</a></li>
								<li><a href="jobs-list-layout.php">Gérer les offres</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-post-a-job.php"> Publier un offre</a></li>
										<li><a href="jobs-list-layout.php"> Consulter la liste des offres</a></li>
										
									
									</ul>
								</li>
								<li><a href="dashboard-manage-candidates.php">Gérer la liste des condidatures</a>
									<ul class="dropdown-nav">
										<li><a href="dashboard-manage-candidates.php">Consulter mes listes</li>
                                         <li><a href="find_profile.php">Rechercher un profils </li>											
									</ul>
								</li>
							<a href="dashboard-settings.php">Paramètres</a>
							</ul>
						</li>
					</ul>
				</nav>
				<div class="clearfix"></div>
				<!-- Main Navigation / End -->
				
			</div>
			<!-- Left Side Content / End -->


			<!-- Right Side Content / End -->
			<div class="right-side">

	            <!--  User Notifications / End -->

				<!-- User Menu -->
				<div class="header-widget">

					<!-- Messages -->
					<div class="header-notifications user-menu">
						<div class="header-notifications-trigger">
							<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
						</div>

						<!-- Dropdown -->
						<div class="header-notifications-dropdown">

							<!-- User Status -->
							<div class="user-status">

								<!-- User Name / Avatar -->
								<div class="user-details">
									<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
									<div class="user-name">
									<?= 
$res2[3] ?> <?= 
$res2[2] ;}}?> <span>Employeur</span>
									</div>
								</div>
								
								<!-- User Status Switcher -->
								<div class="status-switch" id="snackbar-user-status">
									<label class="user-online current-status">Online</label>
									<label class="user-invisible">Invisible</label>
									<!-- Status Indicator -->
									<span class="status-indicator" aria-hidden="true"></span>
								</div>	
						</div>
						
						<ul class="user-menu-small-nav">
							<li><a href="dashboard_pers_morale.php"><i class="icon-material-outline-dashboard"></i> Dashboard</a></li>
							<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
							<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i>Logout</li>
						</ul>

						</div>
					</div>

				</div>
				<!-- User Menu / End -->

				<!-- Mobile Navigation Button -->
				<span class="mmenu-trigger">
					<button class="hamburger hamburger--collapse" type="button">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</button>
				</span>

			</div>
			<!-- Right Side Content / End -->

		</div>
	</div>
	<!-- Header / End -->

</header>
<div class="clearfix"></div>
<!-- Header Container / End -->
<!-- Titlebar
================================================== -->
<?php 


//echo "<h6>ID " . $_GET["id"] . "</h6>";
 
//echo"'" . $_SESSION["id_per"]. "'";
 $sql1 = "SELECT * FROM personne_morale offre_emploi WHERE id_persmorale='".$_SESSION['id_per']."'";
  $psw=mysqli_query($con,$sql1);
  while($res=mysqli_fetch_array($psw)) {
	  $pw=$res['nom'];
       //echo $pw;
  }

				

$result = mysqli_query($con,"SELECT * FROM offre_emploi ");
if (mysqli_num_rows($result) > 0 ) {
	 $i=0;
while($row = mysqli_fetch_array($result)) {

			if($row[0] == $_GET["id"]   )
							   
                       
					   {            
							
						
echo"
	

	
<div class='single-page-header' data-background-image='images/single-job.jpg'>
	<div class='container'>
		<div class='row'>
			<div class='col-md-12'>
				<div class='single-page-header-inner'>
				
					<div class='left-side'>
						<div class='header-image'><a href='single-company-profile.html'><img src='images/$row[12]' ></a></div>
						<div class='header-details'>
						    
							<h3>$row[1] </h3>
							<h5>À propos de l'employeur</h5>
							$pw
						</div>
					</div>
					<div class='right-side'>
						<div class='salary-box'>
							<div class='salary-type'>Salaire annuel</div>
							<div class='salary-amount'>$row[6] DT à $row[7] DT </div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>


<!-- Page Content
================================================== -->
<div class='container'>
	<div class='row'>
		
		<!-- Content -->
		<div class='col-xl-8 col-lg-8 content-right-offset'>

			<div class='single-page-section'>
				<h3 class='margin-bottom-25'>Description de l'emploi</h3>
				<p>$row[11]</p>
			</div>

			<div class='single-page-section'>
				<h3 class='margin-bottom-30'>Emplacement</h3>
				<div id='single-job-map-container'>
					<div id='singleListingMap' data-latitude='51.507717' data-longitude='-0.131095' data-map-icon='im im-icon-Hamburger'></div>
					<a href='#' id='streetView'>$row[5]</a>
				</div>
			</div>

			<div class='single-page-section'>
				<h3 class='margin-bottom-25'></h3>

				<!-- Listings Container -->
				<div class='listings-container grid-layout'>

						<!-- Job Listing -->
						<a href='#' class='job-listing'>

							

							
						</a>
					</div>
					<!-- Listings Container / End -->

				</div>
		</div>
		

		<!-- Sidebar -->
		<div class='col-xl-4 col-lg-4'>
			<div class='sidebar-container'>

				<a href='#small-dialog' class='apply-now-button popup-with-zoom-anim'>Appliquer maintenant <i class='icon-material-outline-arrow-right-alt'></i></a>
					
				<!-- Sidebar Widget -->
				<div class='sidebar-widget'>
					<div class='job-overview'>
						<div class='job-overview-headline'>Résumé de l'offre</div>
						<div class='job-overview-inner'>
							<ul>
								<li>
									<i class='icon-material-outline-location-on'></i>
									<span>Emplacement</span>
									<h5>$row[5]</h5>
								</li>
								<li>
									<i class='icon-material-outline-business-center'></i>
									<span>Type d'emploi</span>
									<h5>$row[3]</h5>
								</li>
								<li>
									<i class='icon-material-outline-local-atm'></i>
									<span>Salaire</span>
									
									<h5>$row[6] ===> $row[7] DT</h5>
								</li>
								<li>
									<i class='icon-material-outline-access-time'></i>
									<span>Date postée</span>
									<h5>$row[10]</h5>
								</li>
							</ul>
						</div>
					</div>
				</div>

				

			</div>
		</div>

	</div>
</div>
";}}
}

?>

<!-- Footer
================================================== -->
<div id="footer">
	
	<!-- Footer Top Section -->
	<div class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">

					<!-- Footer Rows Container -->
					<div class="footer-rows-container">
						
						<!-- Left Side -->
						<div class="footer-rows-left">
							<div class="footer-row">
								<div class="footer-row-inner footer-logo">
									<img src="images/logo2.png" alt="">
								</div>
							</div>
						</div>
						
						<!-- Right Side -->
						<div class="footer-rows-right">

							<!-- Social Icons -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<ul class="footer-social-links">
										<li>
											<a href="#" title="Facebook" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-facebook-f"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Twitter" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-twitter"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Google Plus" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-google-plus-g"></i>
											</a>
										</li>
										<li>
											<a href="#" title="LinkedIn" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-linkedin-in"></i>
											</a>
										</li>
									</ul>
									<div class="clearfix"></div>
								</div>
							</div>
							
							<!-- Language Switcher -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<select class="selectpicker language-switcher" data-selected-text-format="count" data-size="5">
										<option selected>English</option>
										<option>Français</option>
										<option>Español</option>
										<option>Deutsch</option>
									</select>
								</div>
							</div>
						</div>

					</div>
					<!-- Footer Rows Container / End -->
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Top Section / End -->

	<!-- Footer Middle Section -->
	<div class="footer-middle-section">
		<div class="container">
			<div class="row">

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Pour les candidats</h3>
						<ul>
							<li><a href="#"><span>Parcourir les emplois</span></a></li>
							<li><a href="#"><span>Ajouter un CV</span></a></li>
							<li><a href="#"><span>Alertes d'emploi</span></a></li>
							<li><a href="#"><span>Mes marque-pages</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Pour les employeurs</h3>
						<ul>
							<li><a href="#"><span>Parcourir les candidats</span></a></li>
							<li><a href="#"><span>Publier une offre</span></a></li>
							<li><a href="#"><span>Publier une tâche</span></a></li>
							<li><a href="#"><span>Plans et prix</span></a></li>
						</ul>
					</div>
				</div>

				
			

				<!-- Newsletter -->
				<div class="col-xl-4 col-lg-4 col-md-12">
					<h3><i class="icon-feather-mail"></i> Inscrivez-vous à une newsletter</h3>
					<p>Dernières nouvelles hebdomadaires, analyses et conseils de pointe sur la recherche d'emploi.</p>
					<form action="#" method="get" class="newsletter">
						<input type="text" name="fname" placeholder="Entrez votre adresse email">
						<button type="submit"><i class="icon-feather-arrow-right"></i></button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer Middle Section / End -->
	

	

</div>
<!-- Footer / End -->

</div>
<!-- Wrapper / End -->


<!-- Apply for a job popup
================================================== -->
<div id="small-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">

	<!--Tabs -->
	<div class="sign-in-form">

		<ul class="popup-tabs-nav">
			<li><a href="#tab">Appliquer maintenant</a></li>
		</ul>

		<div class="popup-tabs-container">

			<!-- Tab -->
			<div class="popup-tab-content" id="tab">
				
				<!-- Welcome Text -->
				<div class="welcome-text">
					<h3>Se connecter</h3>
				</div>
					
				<!-- Form -->
				<form method="post" id="apply-now-form">

					

					<div class="input-with-icon-left">
						<i class="icon-material-baseline-mail-outline"></i>
						<input type="text" class="input-text with-border" name="email" id="emailaddress" placeholder="Addresse Email " required/>
					</div>

					<div class="input-with-icon-left">
						<i class="icon-material-outline-lock"></i>
						<input type="password" class="input-text with-border" name="password" id="password" placeholder="Mot de passe" required/>
					</div>

				</form>
				
				<!-- Button -->
				<button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit" form="apply-now-form">Se connecter <i class="icon-material-outline-arrow-right-alt"></i></button>

			</div>

		</div>
	</div>
</div>
<!-- Apply for a job popup / End -->


<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 

// Snackbar for copy to clipboard button
$('.copy-url-button').click(function() { 
	Snackbar.show({
		text: 'Copied to clipboard!',
	}); 
}); 
</script>

<!-- Google API & Maps -->
<!-- Geting an API Key: https://developers.google.com/maps/documentation/javascript/get-api-key -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&amp;libraries=places"></script>
<script src="js/infobox.min.js"></script>
<script src="js/markerclusterer.js"></script>
<script src="js/maps.js"></script>

</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/single-job-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:38:42 GMT -->
</html>