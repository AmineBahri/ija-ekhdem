
			
<?php 
 include("db.php");
 session_start();

if(!empty($_POST['posteocc']) && isset($_POST['posteocc'])
&& !empty($_POST['lieu'])&& isset($_POST['lieu'])
&& isset($_POST['dateD']) && !empty($_POST['dateD'])
&& isset($_POST['dateF']) && !empty($_POST['dateF'])
&& isset($_POST['année']) && !empty($_POST['année'])
&& isset($_POST['specialité']) && !empty($_POST['specialité'])
&& isset($_POST['mention']) && !empty($_POST['mention']) 
&& isset($_POST['nomdip']) && !empty($_POST['nomdip'])
&& isset($_POST['lieuF']) && !empty($_POST['lieuF'])
&& isset($_POST['duréeF']) && !empty($_POST['duréeF'])
&& isset($_POST['sysexp']) && !empty($_POST['sysexp'])
&& isset($_POST['desclog']) && !empty($_POST['desclog'])
&& isset($_POST['autre']) && !empty($_POST['autre'])
&& isset($_POST['niveau']) && !empty($_POST['niveau'])
&& isset($_POST['lang']) && !empty($_POST['lang'])

){ $posteocc= $_POST['posteocc'];
  $lieu=$_POST['lieu'] ;
  $dateD= $_POST['dateD'];
  $dateF= $_POST['dateF'];
  $année= $_POST['année'];
  $specialité= $_POST['specialité'];
  $mention= $_POST['mention'];
  $nomdip= $_POST['nomdip'];
  $lieuF= $_POST['lieuF'];
  $duréeF= $_POST['duréeF'];   
  $sysexp= $_POST['sysexp'];
  $desclog= $_POST['desclog'];
  $autre= $_POST['autre'];
  $niveau= $_POST['niveau'];
  $lang= $_POST['lang'];
  $date1= date("Y-m-d H:i:s");

  $sql = " INSERT INTO demande_emploi (id_offreemploi,id_utilisateur,date_demande) VALUES ('".$_SESSION['idoffre']."' ,'".$_SESSION['id_per']."',
     	  '".$date1."');";
     $result=mysqli_query($con,$sql);
     if(!$result){
      
        die('Error: ' . mysqli_error($con));
        }else{
      echo "1 record added";
        
     $sql6 = "SELECT MAX(id_demandeemp) AS maxid FROM demande_emploi ";
     $psw=mysqli_query($con,$sql6);
     $res=mysqli_fetch_array($psw);
       if($res['maxid']==0) {$pw=1;}else {$pw=$res['maxid'];}
              $sql1 = "INSERT INTO connaissance_linguistiques  (langue_parlee ,niveau_langue,id_demandeemp) VALUES ('$lang', '$niveau', '".$pw."');";
              $sql1 .= "INSERT INTO con_informatique   (description_logiciel,	syst_exploitation, autre_info,id_demandeemp) VALUES ('$desclog', '$sysexp', '$autre','".$pw."');";
              
              $sql1 .= "INSERT INTO diplome   (annee_obtention,mention,specialité,id_demandeemp)  VALUES ('$année','$mention','$specialité','".$pw."');";
                $sql1 .= "INSERT INTO experience_professionnelle  ( poste_occupe,lieu_experience,date_debut,date_fin,id_demandeemp ) VALUES ( '$posteocc','$lieu', '$dateD', '$dateF','".$pw."');";
            $sql1 .= "INSERT INTO formations   (diplome,lieu_formation,duree_formation,id_demandeemp) VALUES	('$nomdip','$lieuF', '$duréeF','".$pw."');";
            
  if( !empty($_POST['posteocc1']) or isset($_POST['posteocc1'])
  or !empty($_POST['lieu1'])or isset($_POST['lieu1'])
  or isset($_POST['dateD1']) or !empty($_POST['dateD1'])
  or isset($_POST['dateF1']) or !empty($_POST['dateF1'])
  or isset($_POST['année1']) or !empty($_POST['année1'])
  or isset($_POST['specialité1']) or !empty($_POST['specialité1'])
  or isset($_POST['mention1']) or !empty($_POST['mention1']) 
  or isset($_POST['nomdip1']) or !empty($_POST['nomdip1'])
  or isset($_POST['lieuF1']) or !empty($_POST['lieuF1'])
  or isset($_POST['duréeF1']) or !empty($_POST['duréeF1'])
  or isset($_POST['sysexp1']) or !empty($_POST['sysexp1'])
  or isset($_POST['desclog1']) or !empty($_POST['desclog1'])
  or isset($_POST['autre1']) or !empty($_POST['autre1'])
  or isset($_POST['niveau1']) or !empty($_POST['niveau1'])
  or isset($_POST['lang1']) or !empty($_POST['lang1'])){

  
   $posteocc1= $_POST['posteocc1'];
   $lieu1=$_POST['lieu1'] ;
   $dateD1= $_POST['dateD1'];
   $dateF1= $_POST['dateF1'];
   $année1= $_POST['année1'];
   $specialité1= $_POST['specialité1'];
   $mention1= $_POST['mention1'];
   $nomdip1= $_POST['nomdip1'];
   $lieuF1= $_POST['lieuF1'];
   $duréeF1= $_POST['duréeF1'];   
   $sysexp1= $_POST['sysexp1'];
   $desclog1= $_POST['desclog1'];
   $autre1= $_POST['autre1'];
   $niveau1= $_POST['niveau1'];
   $lang1= $_POST['lang1'];
     
            $sql1 .= "INSERT INTO connaissance_linguistiques   (langue_parlee ,niveau_langue,id_demandeemp) VALUES ('$lang1', '$niveau1', '".$pw."');";
            $sql1 .= "INSERT INTO con_informatique   (description_logiciel,	syst_exploitation, autre_info,id_demandeemp) VALUES ('$desclog1', '$sysexp1',  '$autre1', '".$pw."');";
             
            $sql .= "INSERT INTO diplome   (annee_obtention,specialité,mention,id_demandeemp)  VALUES ('$année1','$mention1','$specialité1','".$pw."');";
              $sql1 .= "INSERT INTO experience_professionnelle  ( poste_occupe,lieu_experience,date_debut,date_fin,id_demandeemp ) VALUES ( '$posteocc1','$lieu1', '$dateD1', '$dateF1','".$pw."');";
          $sql1 .= "INSERT INTO formations   (diplome,lieu_formation,duree_formation,id_demandeemp) VALUES	('$nomdip1','$lieuF1', '$duréeF1','".$pw."');";
  }if (mysqli_multi_query($con, $sql1)) {
            echo "New records created successfully";
            header("location: jobs-list-layout-user.php");

          } else {
            echo "Error: " . $sql1 . "<br>" . mysqli_error($con);
            header("location: jobs-list-layout-user.php");
            unset($_SESSION['idoffre']);
          }
         
    
        }      
      }
      

      else{
        echo "ERROR: Could not able to execute!!!!" ;
    }
     mysqli_close($con);
 
      
?>