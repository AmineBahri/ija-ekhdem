# NotificationSystemInPHP
Notification System in PHP ang MySql like facebook
