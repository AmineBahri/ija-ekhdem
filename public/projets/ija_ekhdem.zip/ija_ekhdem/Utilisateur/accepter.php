<?php
include("db.php");
session_start();	
													
												
$sql = "Select *  FROM demande_emploi WHERE id_offreemploi='". $_SESSION['id_off']."'";
   
   $exp=mysqli_query($con,$sql);
  while($res=mysqli_fetch_array($exp)) {
	

	  $test=$res['id_demandeemp'];
	  $test1=$res['date_demande'];
	  $test2=$res['id_utilisateur'];
	  $test3=$res['id_offreemploi'];
	  echo $test;
	  echo $test1;
	  echo $test2;
	  echo $test3;
	  												
$sql3 = "Select *  FROM demande_emploi1 WHERE id_offreemploi='". $_SESSION['id_off']."'";
   
   $exp3=mysqli_query($con,$sql3);
  
    $sql1 = "INSERT INTO demande_emploi1 (id_demandeemp, date_demande,id_utilisateur,id_offreemploi) VALUES('$test','$test1', '$test2', '$test3')";
	$exp1=mysqli_query($con,$sql1);
	 //mysqli_query($con,"INSERT INTO demande_emploi1  select * from demande_emploi where (id_offreemploi='" . $_SESSION['id_off']. "') AND ('id_utilisateur='" . $_SESSION["id_per"] . "'')");
    $sql2 = "DELETE   FROM demande_emploi where id_offreemploi='". $_SESSION['id_off']."'";
  $exp2=mysqli_query($con,$sql2);
 
	$query1 ="INSERT INTO notification ( cont_notification,notification_status, id_utilisateur, id_offreemploi) VALUES ( 'vous etes accepté', 0, $test2 ,'". $_SESSION['id_off']."')  ";
	if(mysqli_query($con,$query1)){
		header("location: ../Personne_morale/jobs-list-layout.php"); 

	}

  }
	
		
 
				
				
	
?>