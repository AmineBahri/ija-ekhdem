
<?php  
  include("db.php");
  errot_reporting( E_ALL );
  $from = "test@votredomaine.com";
  $to ="nanouwalha@gmail.com";
  $subject = "Vérification PHP Mail";
  $message = "PHP mail marche";
  $headers = "From:" . $from;
  mail($to,$subject,$message, $headers);
  echo "L'email a été envoyé.";
  ?>