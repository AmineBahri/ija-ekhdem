<!doctype html>
<html lang="en">

<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-settings.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:08 GMT -->
<head>

<!-- Basic Page Needs
================================================== -->
<title> Ija ekhdem </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">
<script src= 
	"https://code.jquery.com/jquery-1.12.4.min.js"> 
		</script> 
</head>
<body class="gray">
<?php
     include("db.php");
     include("notification.php");
     $sql1 = "SELECT * FROM Utilisateur WHERE id_utilisateur='".$_SESSION['id_per']."'";
     $psw=mysqli_query($con,$sql1);
     while($res=mysqli_fetch_array($psw)) {
       $nom=$res['nom'];
       $prenom=$res['prenom'];
       $mail=$res['email'];
       $tel=$res['telephone'];
       
	  
	 
    ?>

<!-- Wrapper -->
<div id="wrapper">
<header id="header-container" class="fullwidth dashboard-header not-sticky">

<!-- Header -->
<div id="header">
	<div class="container">
		
		<!-- Left Side Content -->
		<div class="left-side">
	
<!-- Wrapper -->
			<!-- Logo -->
			<div id="logo">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>

			<!-- Main Navigation -->
			<nav id="navigation">
					<ul id="responsive">
						<li><a href="index.php" class="current">Acceuil</a></li>
						<li><a href="jobs-list-layout-user.php">Consulter Les Offres</a>	</li>
						<li><a href="pages-404.php">Aide</a></li>
						<li><a href="pages-contact.php">Contact</a></li>
					</ul>
				</nav>
		
		<!-- Left Side Content / End -->

			<!--  User Notifications / End -->

			<!-- User Menu -->
			<div class="header-widget">

				<!-- Messages -->
				<div class="header-notifications user-menu">
					<div class="header-notifications-trigger">
						<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
					</div>

					<!-- Dropdown -->
					<div class="header-notifications-dropdown">

						<!-- User Status -->
						<div class="user-status">

							<!-- User Name / Avatar -->
							<div class="user-details">
								<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
								<div class="user-name">
								<?= 
$res['nom'] ?> <?= 
$res['prenom'] ;}?><span>Freelancer</span>
								</div>
							</div>
							
							<!-- User Status Switcher -->
							<div class="status-switch" id="snackbar-user-status">
								<label class="user-online current-status">Online</label>
								<label class="user-invisible">Invisible</label>
								<!-- Status Indicator -->
								<span class="status-indicator" aria-hidden="true"></span>
							</div>	
					</div>
					
					<ul class="user-menu-small-nav">
						<li><a href="monprofile.php"><i class="icon-material-outline-dashboard"></i> Mon profil</a></li>
						<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
						<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i> Logout</a></li>
					</ul>

					</div>
				</div>

			</div>
			<!-- User Menu / End -->

			<!-- Mobile Navigation Button -->
			<span class="mmenu-trigger">
				<button class="hamburger hamburger--collapse" type="button">
					<span class="hamburger-box">
						<span class="hamburger-inner"></span>
					</span>
				</button>
			</span>

		</div>
		<!-- Right Side Content / End -->

	</div>
</div>
<!-- Header / End -->

</header>

<div class="clearfix"></div>
<!-- Header Container / End -->


			<?php $_SESSION['idoffre']=$_GET['ido'];?>
			<form action="Demande_Emploi.php"	 method="post">				

		
			<!-- Row -->
			<div class="row">

				<!-- Dashboard Box -->
				<div class="col-xl-12">
					<div class="dashboard-box margin-top-0">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-account-circle"></i> Informations personnelles</h3>
						</div>

						<div class="content with-padding padding-bottom-0">
	
							<div class="row">

								<div class="col-auto">
									<div class="avatar-wrapper" data-tippy-placement="bottom" title="Change Avatar">
										<img class="profile-pic" src="images/user-avatar-placeholder.png" alt="" />
										<div class="upload-button"></div>
										<input class="file-upload" type="file" accept="image/*"/>
									</div>
								</div>

								<div class="col">
									<div class="row">

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Nom</h5>
												<input type="text" class="with-border" value="<?=$nom?>" >
											</div>
										</div>

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Prenom</h5>
												<input type="text" class="with-border"value="<?=$prenom?>">
											</div>
										</div>

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Email</h5>
												<input type="text" class="with-border" value="<?=$mail?>">
											</div>
										</div>
										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Telephone</h5>
												<input type="text" class="with-border" value="<?=$tel?>">
											</div>
										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				</div>

				<!-- Dashboard Box -->
				<div class="col-xl-12">
					<div class="dashboard-box">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-line-awesome-pencil"></i> Expérience professionnelle</h3>
						</div>
						 <!-- Including jQuery -->
    
		  
						 <div id="extender"></div>
						 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.3/jquery.min.js"></script>      
<script type="text/javascript"> 
      
$(document).ready(function() {
	

  $('#button').click(function() {

 
    $('#container').append(
      $(document.createElement('label')).prop({
        for: 'myCheckBox'
      }).html('<h5>Poste occupé</h5>')
    ).append(document.createElement('br')).append(
      $(document.createElement('input')).prop({
        id: 'myCheckBox',
        name: 'posteocc1',
        type: 'text',
		class: 'with-border'
      })
    );
 

 $('#container').append(
      $(document.createElement('label')).prop({
        for: 'myCheckBox'
      }).html('<h5>Lieu expérience</h5>')
    ).append(document.createElement('br')).append(
	$(document.createElement('input')).prop({
        id: 'myCheckBox',
        name: 'lieu1',
        type: 'text',	
		class: 'with-border'

      })
    );
	$('#container').append(
      $(document.createElement('label')).prop({
        for: 'myCheckBox'
      }).html('<h5>Date Début</h5>')
    ).append(document.createElement('br')).append(
   $(document.createElement('input')).prop({
        id: 'myCheckBox',
        name: 'dateD1',
        type: 'date',	class: 'with-border'

      })
    );
	$('#container').append(
      $(document.createElement('label')).prop({
        for: 'myCheckBox'
      }).html('<h5>Date fin</h5>')
    ).append(document.createElement('br')).append(
   $(document.createElement('input')).prop({
        id: 'myCheckBox',
        name: 'dateF1',
        type: 'date',
		class: 'with-border'

      })
    );
});
});
      
$(document).ready(function() {
	

	$('#button1').click(function() {
  
   
	  $('#container1').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Année obtention</h5>')
	  ).append(document.createElement('br')).append(
		$(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'année1',
		  type: 'Date',
		  class: 'with-border'
		})
	  );
   
  
   $('#container1').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Spécialité</h5>')
	  ).append(document.createElement('br')).append(
	  $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'specialité1',
		  type: 'text',	
		  class: 'with-border'

		})
	  );
	  $('#container1').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Mention</h5>')
	  ).append(document.createElement('br')).append(
	 $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'mention1',
		  type: 'text',	class: 'with-border'

		})
	  );
	 
  });
  });
  $(document).ready(function() {
	

	$('#button2').click(function() {
  
   
	  $('#container2').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Diplome</h5>')
	  ).append(document.createElement('br')).append(
		$(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'nomdip1',
		  type: 'text',
		  class: 'with-border'

		})
	  );
   
  
   $('#container2').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Lieu formation</h5>')
	  ).append(document.createElement('br')).append(
	  $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'lieuF1',
		  type: 'text',	
		  class: 'with-border'

		})
	  );
	  $('#container2').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Durée formation</h5>')
	  ).append(document.createElement('br')).append(
	 $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'duréeF1',
		  type: 'text',	class: 'with-border'

		})
	  );
	 
  });
  });
  $(document).ready(function() {
	

	$('#button3').click(function() {
  
   
	  $('#container3').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Systéme exploitation</h5>')
	  ).append(document.createElement('br')).append(
		$(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'sysexp1',
		  type: 'text',
		  class: 'with-border'

		})
	  );
   
  
   $('#container3').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Description logiciel</h5>')
	  ).append(document.createElement('br')).append(
	  $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'desclog1',
		  type: 'text',	
		  class: 'with-border'
		})
	  );
	  $('#container3').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Autre connaissance</h5>')
	  ).append(document.createElement('br')).append(
	 $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'autre1',
		  type: 'text',	class: 'with-border'

		})
	  );
	 
  });
  });
  $(document).ready(function() {
	

	$('#button4').click(function() {
  
   
	  $('#container4').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Langue parlée</h5>')
	  ).append(document.createElement('br')).append(
		$(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'lang1',
		  type: 'text',
		  class: 'with-border'

		})
	  );
   
  
   $('#container4').append(
		$(document.createElement('label')).prop({
		  for: 'myCheckBox'
		}).html('<h5>Niveau de langue</h5>')
	  ).append(document.createElement('br')).append(
	  $(document.createElement('input')).prop({
		  id: 'myCheckBox',
		  name: 'niveau1',
		  type: 'text',	
		  class: 'with-border'
		  

		})
	  );
	
	 
  });
  });

</script>
				<div class="content">
							
							<div class="row">
									<div class="col-xl-6">
										<div class="submit-field">
											<h5>Poste occupé</h5>
											<input type="text" class="with-border"  name="posteocc" >
										</div>
									</div>

									<div class="col-xl-6">
										<div class="submit-field">
											<h5>Lieu expérience</h5>
											<input type="text" class="with-border"  name="lieu" >
										</div>
									</div>
									<div class="col-xl-6">
										<div class="submit-field">
											<h5>Date début</h5>
											<input type="date" class="with-border"  name="dateD" >
										</div>
									</div>
									<div class="col-xl-6">
										<div class="submit-field">
											<h5>Date fin</h5>
											<input type="date" class="with-border"  name="dateF" >
										</div>
									</div>
									
					<div id="container"  ></div>
					<input type="button" id="button" value="Add"></input>

					
	
						
					</div>
					
				</div>
				
                 <div class="col-xl-12">
					<div id="test1" class="dashboard-box">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-school"></i> Diplome</h3>
						</div>

						<div class="content with-padding">
							<div class="row">
							<div class="col-xl-4">
									<div class="submit-field">
										<h5>Annee obtention</h5>
										<input type="date" class="with-border" name="année" >
										  
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Spécialité</h5>
										<input type="text" class="with-border" name="specialité" >
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Mentions</h5>
										<select name="mention" >
										<option name="mention" >Passable</option>
										<option name="mention">Assez bien</option>
										<option name="mention" >Bien</option>
										<option name="mention" >Trés bien</option>
										<option name="mention">Excellent</option>
										</select>
									</div>
								</div>
								<div id="container1"  class="with-border"></div>
								<input type="button" id="button1" value="Add"></input>
  </div> 
				  </div>
		  

							
                             </div>
							 </div>
							
							<div class="col-xl-12">
					<div id="test1" class="dashboard-box">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-school"></i> Formations</h3>
						</div>

						<div class="content with-padding">
							<div class="row">
							<div class="col-xl-4">
									<div class="submit-field">
										<h5>Diplome</h5>
										<input type="text" class="with-border" name="nomdip" >
										  
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Lieu formation</h5>
										<input type="text" class="with-border" name="lieuF" >
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Durée formation</h5>
										<input type="text" class="with-border" name="duréeF">
									</div>
								</div>
								

					
	  	
							
							
						
						</div>	<div id="container2"  class="with-border"></div>
						<input type="button" id="button2" value="Add">

  </div> 
				  </div>
		  

						
				 </div>
				 </div>
				 
				 
				 
				 
				<!-- Dashboard Box -->
				<div class="col-xl-12">
					<div id="test1" class="dashboard-box">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-desktop-mac"></i> Connaissance Informatique</h3>
						</div>

						<div class="content with-padding">
							<div class="row">
							<div class="col-xl-4">
									<div class="submit-field">
										<h5>Systéme exploitation</h5>
										<input type="text" class="with-border" name="sysexp" >
										  
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Description logiciel</h5>
										<input type="text" class="with-border" name="desclog" >
									</div>
								</div>
								
							<div class="col-xl-12">
										<div class="submit-field">
											<h5>Autre connaissance</h5>
											<input type="text" class="with-border"name="autre" ></textarea>
										</div>
									</div>
						
						</div>
						<div id="container3"  class="with-border"></div>
						<input type="button"  id="button3" value="Add">

  </div> 
				  </div>
		  

	  
								
							</div>
						</div>
				</div>
				<!-- Dashboard Box -->
				<div class="col-xl-12">
					<div id="test1" class="dashboard-box">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-add-circle-outlin"></i>Connaissance Linguistiques</h3>
						</div>

						<div class="content with-padding">
							<div class="row">
							<div class="col-xl-4">
									<div class="submit-field">
										<h5>Langue parlée</h5>
									
											<select class="selectpicker with-border" data-size="7" title="Choississez la langue" name="lang" data-live-search="true" multiple>
												<option value="ENG" name="lang" > Anglais</option>
												<option value="AR" name="lang" >Arabe</option>
												<option value="BNG" name="lang" >bengali</option>
												<option value="CH" name="lang" >chinois</option>
												<option value="FR" name="lang">Français</option>
												<option value="HI" name="lang" >hindi</option>
												<option value="JAP" name="lang" >japonais</option>
												<option value="POR" name="lang" >portugais</option>
												<option value="RU" name="lang" >russe</option>
												
												
											</select>
										</div>
										  
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Niveau de langue</h5>
									<select name="niveau" >
									  <option name="niveau">Débutant</option>
									  <option name="niveau">Intermdiaire</option>
									  <option name="niveau">Expert</option>
									</select>
									</div>
								</div><br>
								
								
							
						<div id="container4"  class="with-border"></div>
						<input type="button" id="button4" value="Add"> 

</div>
  							</div>						
</div>
					
			<!-- Button -->
			<div class="col-xl-12">
					<input type="submit" class="button ripple-effect big margin-top-30">
				</div>
				
							
</form>
			<!-- Row / End -->

					</div>
	</div>
	<!-- Dashboard Content / End -->

</div>
<!-- Dashboard Container / End -->

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 
</script>
<script type="text/javaScript"> 
    function fAddText() { 
        document.getElementById('Cible').innerHTML ='<input type="text"/>'; 
    } 
</script> 
<!-- Chart.js // documentation: http://www.chartjs.org/docs/latest/ -->
<script src="js/chart.min.js"></script>
<script>
	Chart.defaults.global.defaultFontFamily = "Nunito";
	Chart.defaults.global.defaultFontColor = '#888';
	Chart.defaults.global.defaultFontSize = '14';

	var ctx = document.getElementById('chart').getContext('2d');

	var chart = new Chart(ctx, {
		type: 'line',

		// The data for our dataset
		data: {
			labels: ["January", "February", "March", "April", "May", "June"],
			// Information about the dataset
	   		datasets: [{
				label: "Views",
				backgroundColor: 'rgba(42,65,232,0.08)',
				borderColor: '#2a41e8',
				borderWidth: "3",
				data: [196,132,215,362,210,252],
				pointRadius: 5,
				pointHoverRadius:5,
				pointHitRadius: 10,
				pointBackgroundColor: "#fff",
				pointHoverBackgroundColor: "#fff",
				pointBorderWidth: "2",
			}]
		},

		// Configuration options
		options: {

		    layout: {
		      padding: 10,
		  	},

			legend: { display: false },
			title:  { display: false },

			scales: {
				yAxes: [{
					scaleLabel: {
						display: false
					},
					gridLines: {
						 borderDash: [6, 10],
						 color: "#d8d8d8",
						 lineWidth: 1,
	            	},
				}],
				xAxes: [{
					scaleLabel: { display: false },  
					gridLines:  { display: false },
				}],
			},

		    tooltips: {
		      backgroundColor: '#333',
		      titleFontSize: 13,
		      titleFontColor: '#fff',
		      bodyFontColor: '#fff',
		      bodyFontSize: 13,
		      displayColors: false,
		      xPadding: 10,
		      yPadding: 10,
		      intersect: false
		    }
		},


});

</script>


<!-- Google Autocomplete -->
<script>
	function initAutocomplete() {
		 var options = {
		  types: ['(cities)'],
		  // componentRestrictions: {country: "us"}
		 };

		 var input = document.getElementById('autocomplete-input');
		 var autocomplete = new google.maps.places.Autocomplete(input, options);

		if ($('.submit-field')[0]) {
		    setTimeout(function(){ 
		        $(".pac-container").prependTo("#autocomplete-container");
		    }, 300);
		}
	}

</script>

<!-- Google API -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&amp;libraries=places&amp;callback=initAutocomplete"></script>


</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-settings.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:08 GMT -->
</html>
