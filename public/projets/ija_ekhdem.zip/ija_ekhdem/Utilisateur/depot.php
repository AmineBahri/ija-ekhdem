<?php
 include("db.php");

 session_start();
 if(!empty($_FILES)){
 if(!empty($_POST['nomp']) && isset($_POST['nomp'])
 && !empty($_POST['prixp'])&& isset($_POST['prixp'])
 && isset($_POST['comp']) && !empty($_POST['comp'])
 ){
    $titre= $_POST['nomp'];
    $prixp=$_POST['prixp'] ;
    $name= $_FILES['contp']['name'];
    $extension= strrchr($name,'.');
    $comp= $_POST['comp'];
    $date1= date("Y-m-d");

    $extension_autorisees = array('.rar', '.RAR', '.zip', 'ZIP');
    $file_tmp_name=$_FILES['contp']['tmp_name'];
    $file_dest = '../Personne_morale/files/'.$name;
    if (in_array($extension,$extension_autorisees)){
if(move_uploaded_file($file_tmp_name,$file_dest))
   
echo "fichier envoyé avec succès";
    $sql = " INSERT INTO projet ( nom_projet,prix_projet,competences,url_projet,date_depot,id_utilisateur,id_offreemploi) VALUES ('$name','$prixp','$comp', '$file_dest','$date1',".$_SESSION['id_per'].",".$_SESSION['idoff'].")";
$result=mysqli_query($con,$sql);
if(!$result){

  die('Error: ' . mysqli_error($con));
  }}else{
echo "1 record added";
echo "erreur de l'envoi du fichier";

 } }  else{
   echo "Seuls les fichiers zip ou rar";
 }
 }
 ?>