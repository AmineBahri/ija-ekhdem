

<?php 
  include("db.php");
  session_start();
  
  if(!empty($_POST['cin']) && isset($_POST['cin'])
 && !empty($_POST['nom'])&& isset($_POST['nom'])
 && isset($_POST['prenom']) && !empty($_POST['prenom'])
 && isset($_POST['adresse']) && !empty($_POST['adresse'])
 && isset($_POST['email']) && !empty($_POST['email'])
 && isset($_POST['tel']) && !empty($_POST['tel'])
 && isset($_POST['date_nais']) && !empty($_POST['date_nais']) 
 && isset($_POST['pswact']) && !empty($_POST['pswact'])
 && isset($_POST['pswnv']) && !empty($_POST['pswnv'])
 && isset($_POST['pswcnf']) && !empty($_POST['pswcnf'])){
      
    $cin= $_POST['cin'];
    $nom=$_POST['nom'] ;
    $prenom= $_POST['prenom'];
    $adresse= $_POST['adresse'];
    $email= $_POST['email'];
    $tel= $_POST['tel'];
    $date_nais= $_POST['date_nais'];
    $pswact= $_POST['pswact'];
    $pswnv= $_POST['pswnv'];
    $pswcnf= $_POST['pswcnf'];
   
  $sql1 = "SELECT * FROM Utilisateur WHERE id_utilisateur='".$_SESSION['id_per']."'";
  $psw=mysqli_query($con,$sql1);
  while($res=mysqli_fetch_array($psw)) {$pw=$res['password'];}
      if($pswact==$pw){
      if($pswcnf==$pswnv){
      $sql = " UPDATE Utilisateur  SET
      cin = '$cin',nom = '$nom',prenom = '$prenom',adresse = '$adresse',
      email = '$email', telephone = '$tel',date_naissance = '$date_nais',password='$pswnv' 
      WHERE id_utilisateur = '".$_SESSION['id_per']."'";
      $result=mysqli_query($con,$sql);
      header("location: monprofile.php"); 

       } else {
              echo "The confirmation password must be compatible with the new one ";
  
          }}else{
            echo "password incorrecte";
          }}
       else{
          echo "please complete all fields";
      }
       
      // Close connection
      
      if(isset($__POST['deconnexion'])){
              session_destroy();
  
      }
  
      mysqli_close($con);
  
        ?>
  