<?php 
class Personne{
	public $cin;
	public $nom;
	public $prenom;
	public $sex;
	public $adresse;
	public $tel;
	public $mdp;
	
	public function getcin(){
 		echo $cin;
 	}
 	public function setcin($cin){
 		$this->cin=$cin;
 	}
 	public function getnom(){
 		echo $nom;
 	}
 	public function setnom($nom){
 		$this->nom=$nom;
 	}
 	public function getprenom(){
 		echo $prenom;
 	}
 	public function setprenom($prenom){
 		$this->prenom=$prenom;
 	}
	public function getsex(){
 		echo $sex;
 	}
 	public function setsex($sex){
 		$this->sex=$sex;
	}
	public function gettel(){
 		echo $tel;
 	}
 	public function settel($tel){
 		$this->tel=$tel;
	}
	public function getadresse(){
 		echo $adresse;
 	}
 	public function setadresse($adresse){
 		$this->adresse=$adresse;
	}
 	public function getmdp(){
 		echo $mdp;
 	}
 	public function setmdp($mdp){
 		$this->mdp=$mdp;
 	}
 	public function insert(){
    try {

	$bdd= new PDO('mysql:host=localhost;dbname=base2;charset=utf8', 'root', '');

}
    catch(Exeption $e){
    die('Erreur : '.$e->getmessage());
   }  
   $req = $bdd->prepare('INSERT INTO client2(cin, nom, prenom,sex,adresse,tel,mdp) VALUES(?, ?, ?, ?, ?, ?, ?)');

	$req->execute(array($this->cin,$this->nom,$this->prenom,$this->sex,$this->adresse,$this->tel,$this->mdp));
    echo " le client est ajouté !!";

 	}
	
  
}
Class Reservation{
	
	private $cin;
	private $numc;
	private $per;
	
	
	
	public function getnumc(){
 		echo $numc;
 	}
 	public function setnumc($numc){
 		$this->numc=$numc;
 	}
	
	public function getcin(){
 		echo $cin;
 	}
 	public function setcin($cin){
 		$this->cin=$cin;
 	}
	public function getper(){
 		echo $per;
 	}
 	public function setper($per){
 		$this->per=$per;
 	}
	
	public function insert(){
    try {
	$bdd= new PDO('mysql:host=localhost;dbname=base2;charset=utf8', 'root', '');

}
    catch(Exeption $e){
    die('Erreur : '.$e->getmessage());
   } 
   
   $req = $bdd->prepare('INSERT INTO reservation1(cin,numc,per) VALUES(? ,?, ?)');

	$req->execute(array($this->cin,$this->numc,$this->per));
    echo " la reservation est fait !!" ; 

	}	
	public function supprimer(){
		 try {

	$bdd= new PDO('mysql:host=localhost;dbname=base2;charset=utf8', 'root', '');

}
    catch(Exeption $e){
    die('Erreur : '.$e->getmessage());
   } 
    $req = $bdd->query("DELETE FROM reservation1 WHERE cin ='".$this->cin."'");
    echo " la suppression est fait !!" ; 
   
	 }
	 public function modifier(){
		 try {

	$bdd= new PDO('mysql:host=localhost;dbname=base2;charset=utf8', 'root', '');

}
    catch(Exeption $e){
    die('Erreur : '.$e->getmessage());
   } echo "Entrez vos champs"; 
$req = $bdd->query("INSERT INTO reservation1( cin,numc, per, des,date) VALUES ( '$cin','$numc', '$per')" );    

  
    echo " la modification est fait !!" ; 
   
	 }
	 
}
?>