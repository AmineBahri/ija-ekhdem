<html>
<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-post-a-job.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:00 GMT -->
<head>
<?php 
  include("db.php");
  include("notification.php");
  
  $auth = "SELECT * FROM  Utilisateur where (id_utilisateur='".$_SESSION['id_per']."')";
   $psw2=mysqli_query($con,$auth);
   {
	   while($res2=mysqli_fetch_array($psw2)) {
	   $nomut=$res2[3];
	   $prenomut=$res2[4];
	  

?>
<!-- Basic Page Needs
================================================== -->
<title> Ija ekhdem </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">
<header id="header-container" class="fullwidth dashboard-header not-sticky">

<!-- Header -->
<div id="header">
	<div class="container">
		
		<!-- Left Side Content -->
		<div class="left-side">
	
<!-- Wrapper -->
			<!-- Logo -->
			<div id="logo">
				<a href="index.php"><img src="images/logo.png" alt=""></a>
			</div>

			<!-- Main Navigation -->
			<nav id="navigation">
				<ul id="responsive">

					<li><a href="index.php">Acceuil</a>
						<ul class="dropdown-nav">
							<li><a href="monprofile.php">Mon profile</a></li>
							<li><a href="jobs-list-layout-user.php">Consulter les offres</a>
						</ul>
					</li>

				
								
						
							
						</ul>
					</li>
				</ul>
			</nav>
		
		<!-- Left Side Content / End -->

			<!--  User Notifications / End -->

			<!-- User Menu -->
			<div class="header-widget">

				<!-- Messages -->
				<div class="header-notifications user-menu">
					<div class="header-notifications-trigger">
						<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
					</div>

					<!-- Dropdown -->
					<div class="header-notifications-dropdown">

						<!-- User Status -->
						<div class="user-status">

							<!-- User Name / Avatar -->
							<div class="user-details">
								<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
								<div class="user-name">
								<?= 
$res2[3] ?> <?= 
$res2[2] ;}}?> <span>Freelancer</span>
								</div>
							</div>
							
							<!-- User Status Switcher -->
							<div class="status-switch" id="snackbar-user-status">
								<label class="user-online current-status">Online</label>
								<label class="user-invisible">Invisible</label>
								<!-- Status Indicator -->
								<span class="status-indicator" aria-hidden="true"></span>
							</div>	
					</div>
					
					<ul class="user-menu-small-nav">
						<li><a href="monprofile.php"><i class="icon-material-outline-dashboard"></i> Mon profil</a></li>
						<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
						<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i> Logout</a></li>
					</ul>

					</div>
				</div>

			</div>
			<!-- User Menu / End -->

			<!-- Mobile Navigation Button -->
			<span class="mmenu-trigger">
				<button class="hamburger hamburger--collapse" type="button">
					<span class="hamburger-box">
						<span class="hamburger-inner"></span>
					</span>
				</button>
			</span>

		</div>
		<!-- Right Side Content / End -->

	</div>
</div>
<!-- Header / End -->

</header>

<!-- Dashboard Box -->
<div class="col-xl-12">
	
	<div class="dashboard-box margin-top-0">

		<!-- Headline -->
		<div class="headline">
			<h3><i class="icon-material-outline-account-circle"></i> Profile </h3>
		</div>

		<div class="content with-padding padding-bottom-0">

			<div class="row">

			
                <?php 
   include("db.php");
   	

 $sql1 = "SELECT * FROM Utilisateur AS U WHERE (U.id_utilisateur='".$_SESSION['id_per']."') ";
 $psw=mysqli_query($con,$sql1);
 while($res=mysqli_fetch_array($psw)) {
   $nom=$res['nom'];
   $prenom=$res['prenom'];
   $mail=$res['email'];
   $date_naissance=$res['date_naissance'];
   $adresse=$res['adresse'];
   $tel=$res['telephone'];


 }
   ?>
  <div class="col-xl-12">
					<div class="dashboard-box margin-top-0">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-material-outline-account-circle"></i> Informations personnelles</h3>
						</div>

						<div class="content with-padding padding-bottom-0">
	
							<div class="row">

								<div class="col-auto">
									<div class="avatar-wrapper" data-tippy-placement="bottom" title="Change Avatar">
										<img class="profile-pic" src="images/user-avatar-big-01.jpg" alt="" />
										<div class="upload-button"></div>
										<input class="file-upload" type="file" accept="image/*"/>
									</div>
								</div>

								<div class="col">
									<div class="row">

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Nom</h5>
												<h2><?=$nom?></h2>
											</div>
										</div>

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Prenom</h5>
												<h2> <?=$prenom?></h2>
											</div>
										</div>

										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Email</h5>
												<h2><?=$mail?></h2>
											</div>
										</div>
										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Adresse</h5>
												<h2><?=$adresse?></h2>
											</div>
										</div>
										<div class="col-xl-6">
											<div class="submit-field">
												<h5>Telephone</h5>
												<h2><?=$tel?></h2>
											</div>
										</div>

									</div>
								</div>
							</div>

						</div>
					</div>
				</div>

								
</div>
					
		<!-- Row / End -->

					</div>
	</div>
	<!-- Dashboard Content / End -->

</div>
<!-- Dashboard Container / End -->

</div>
<!-- Wrapper / End -->


<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 
</script>
<script type="text/javaScript"> 
    function fAddText() { 
        document.getElementById('Cible').innerHTML ='<input type="text"/>'; 
    } 
</script> 
<!-- Chart.js // documentation: http://www.chartjs.org/docs/latest/ -->
<script src="js/chart.min.js"></script>
<script>
	Chart.defaults.global.defaultFontFamily = "Nunito";
	Chart.defaults.global.defaultFontColor = '#888';
	Chart.defaults.global.defaultFontSize = '14';

	var ctx = document.getElementById('chart').getContext('2d');

	var chart = new Chart(ctx, {
		type: 'line',

		// The data for our dataset
		data: {
			labels: ["January", "February", "March", "April", "May", "June"],
			// Information about the dataset
	   		datasets: [{
				label: "Views",
				backgroundColor: 'rgba(42,65,232,0.08)',
				borderColor: '#2a41e8',
				borderWidth: "3",
				data: [196,132,215,362,210,252],
				pointRadius: 5,
				pointHoverRadius:5,
				pointHitRadius: 10,
				pointBackgroundColor: "#fff",
				pointHoverBackgroundColor: "#fff",
				pointBorderWidth: "2",
			}]
		},

		// Configuration options
		options: {

		    layout: {
		      padding: 10,
		  	},

			legend: { display: false },
			title:  { display: false },

			scales: {
				yAxes: [{
					scaleLabel: {
						display: false
					},
					gridLines: {
						 borderDash: [6, 10],
						 color: "#d8d8d8",
						 lineWidth: 1,
	            	},
				}],
				xAxes: [{
					scaleLabel: { display: false },  
					gridLines:  { display: false },
				}],
			},

		    tooltips: {
		      backgroundColor: '#333',
		      titleFontSize: 13,
		      titleFontColor: '#fff',
		      bodyFontColor: '#fff',
		      bodyFontSize: 13,
		      displayColors: false,
		      xPadding: 10,
		      yPadding: 10,
		      intersect: false
		    }
		},


});

</script>


<!-- Google Autocomplete -->
<script>
	function initAutocomplete() {
		 var options = {
		  types: ['(cities)'],
		  // componentRestrictions: {country: "us"}
		 };

		 var input = document.getElementById('autocomplete-input');
		 var autocomplete = new google.maps.places.Autocomplete(input, options);

		if ($('.submit-field')[0]) {
		    setTimeout(function(){ 
		        $(".pac-container").prependTo("#autocomplete-container");
		    }, 300);
		}
	}

</script>

<!-- Google API -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&amp;libraries=places&amp;callback=initAutocomplete"></script>


</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-settings.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:08 GMT -->
</html>
