<?php
  include("db.php");
  session_start();
 $sql = "DELETE FROM Utilisateur WHERE id_utilisateur='".$_SESSION['id_per']."'";
 $supp=mysqli_query($con,$sql);

include('deconnecter.php')?>