<?php
include("db.php");
session_start();
if(isset($_POST['ajouter'])){
		      $titre_offre = $_POST['titre_offre'];
		      $type_offre = $_POST['type_offre'];
		      $equipe = $_POST['equipe'];
              $categorie_offre = $_POST['categorie_offre'];  
		      $date_publication = $_POST['date_publication'];
		      $durée= $_POST['durée'];
			  $emplacement = $_POST['emplacement'];
		      $salaire_min = $_POST['salaire_min'];
			  $salaire_max = $_POST['salaire_max'];
			  $nombre_poste = $_POST['nombre_poste'];
              $description_offre = $_POST['description_offre'];
			   $image = $_FILES['image']['name'];
		      move_uploaded_file($_FILES['image']['tmp_name'],"images/$image");
			  $ins=mysqli_query($con,"INSERT INTO offre_emploi VALUES(NULL, '$titre_offre','$type_offre','$equipe','$categorie_offre','$emplacement','$salaire_min','$salaire_max','$nombre_poste','$durée','$date_publication','$description_offre', '$image', NULL , NULL)");

			   //$ins=mysqli_query($con,"INSERT INTO utilisateur VALUES(NULL, '$cin','$nom','$prenom','$email','$password','$adresse','$telephone','$date_naissance')");
			 

                        while(list($email,$password)=
						mysqli_fetch_array($ins)); 
						 if ($ins == 0  )
		      
			             echo"Veuillez vérifier les champs"; 
						 else 
					
						  header("location: dashboard-manage-jobs.php"); 
		   
}   
		 ?>
<html>
<head>
<title>IJA EKHDEM</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="css/register.css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</head>
<div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="images/user-avatar-placeholder.png" alt=""/>
                        <h3>Bienvenue Admin to ajouter un offre</h3>
                       
                    </div>
                    <div class="col-md-9 register-right">
                        
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Postuler un offre</h3>
								<form method="post">
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="titre_offre"placeholder="Titre_offre *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <select name="type_offre"class="form-control">
											<option value="À plein temps">À plein temps</option>
											<option value="Freelance">Freelance</option>
											<option value="À temps partiel">À temps partiel</option>
											<option value="Stage">Stage</option>
											<option value="Temporary">Temporary</option>
											</select>
					                    </div>
                                        <div class="form-group">
                                            <select name="equipe"class="form-control">
											<option value="MobiSM">MobiSM</option>
											<option value="Autres équipes">Autres équipes</option>
											</select>
                                        </div>
                                        <div class="form-group">
                                          <select name="categorie_offre"class="form-control" data-size="7" title="Select Category">
											<option value="Comptabilité et finance">Comptabilité et finance</option>
											<option value="Bureau et saisie de données">Bureau et saisie de données</option>
											<option value="Conseils">Conseils</option>
											<option value="Administration des tribunaux">Administration des tribunaux</option>
											<option value="Ressources humaines">Ressources humaines</option>
											<option value="Informatique et ordinateurs">Informatique et ordinateurs</option>
											<option value="Forces de l'ordre">Forces de l'ordre</option>
											<option value="La gestion">La gestion</option>
											<option value="Divers">Divers</option>
											<option value="Relations publiques">Relations publiques</option>
										 </select>
                                        </div>
                                        <div class="form-group">
                                            <input type="date" class="form-control" name="date_publication" value="" />
                                        </div>
										<div class="form-group">
										<input  name="image" type="file" >
										</div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="emplacement"placeholder="Emplacement *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="number" name="salaire_min" class="form-control" placeholder="Salaire min *" value="" />
											
                                        </div>
                                        <div class="form-group">
                                            <input type="number" class="form-control" name="salaire_max" placeholder="Salaire max"value="" />
                                        </div>
										<div class="form-group">
                                            <input type="number" class="form-control" name="nombre_poste" placeholder="Nombre poste"value="" />
                                        </div>
										<div class="form-group">
                                            <input type="text" class="form-control" name="durée" placeholder="durée en jours"value="" />
                                        </div>
										<div class="form-group">
                                            <textarea type="text" class="form-control" name="description_offre"placeholder="description de l'offre">
											</textarea>
                                        </div>
										
                                        <input type="submit" class="btnRegister" name="ajouter" value="Ajouter offre"/>
                                    </div>
                                </div>
								</form>
                            </div>
                       
                        </div>
                    </div>
                </div>

            </div>