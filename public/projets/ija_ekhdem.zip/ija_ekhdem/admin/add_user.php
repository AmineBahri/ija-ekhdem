<?php
include("db.php");
session_start();
if(isset($_POST['ajouter'])){
			  $cin = $_POST['cin'];
		      $nom = $_POST['nom'];
		      $prenom = $_POST['prenom'];
		      $nom_societe = $_POST['nom_societe'];
              $email = $_POST['email'];  
		      $password = $_POST['password'];
		      $adresse = $_POST['adresse'];
		      $telephone = $_POST['telephone'];
		      $date_naissance= $_POST['date_naissance'];
			  $domaine = $_POST['domaine'];
             	
		   
			   $ins=mysqli_query($con,"INSERT INTO utilisateur VALUES(NULL, '$cin','$nom','$prenom','$email','$password','$adresse','$telephone','$date_naissance')");
			 

                        while(list($email,$password)=
						mysqli_fetch_array($ins)); 
						 if ($ins == 0  )
		      
			             echo"Veuillez vérifier les champs"; 
						 else 
					
						  header("location: dashboard-manage-users.php"); 
		   
}   
		 ?>
<html>
<head>
<title>IJA EKHDEM</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="css/register.css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

</head>
<div class="container register">
                <div class="row">
                    <div class="col-md-3 register-left">
                        <img src="images/user-avatar-placeholder.png" alt=""/>
                        <h3>Bienvenue Admin to ajouter un utilsateur</h3>
                       
                    </div>
                    <div class="col-md-9 register-right">
                        
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <h3 class="register-heading">Postuler en tant qu'utilisateur</h3>
								<form method="post">
                                <div class="row register-form">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="nom" placeholder="Nom *"  />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="prenom"placeholder="Prenom *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" name="password"placeholder="Password *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control"maxlength="8" name="cin" placeholder="CIN *" value="" />
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email"placeholder="Email *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" name="telephone" class="form-control" placeholder="telephone *" value="" />
                                        </div>
                                        <div class="form-group">
                                            <input type="date" class="form-control" name="date_naissance" value="" />
                                        </div>
										<div class="form-group">
                                            <input type="text" class="form-control" name="adresse" placeholder="adress"value="" />
                                        </div>
                                        <input type="submit" class="btnRegister" name="ajouter" value="Ajouter utilisateur"/>
                                    </div>
                                </div>
								</form>
                            </div>
                       
                        </div>
                    </div>
                </div>

            </div>