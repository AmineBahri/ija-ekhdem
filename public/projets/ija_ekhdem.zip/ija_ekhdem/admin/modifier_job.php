<?php 
  include("db.php");
  session_start();
  if(!empty($_POST['titre_offre']) && isset($_POST['titre_offre'])
 && !empty($_POST['type_offre'])&& isset($_POST['type_offre'])
 && isset($_POST['equipe']) && !empty($_POST['equipe'])
 && isset($_POST['categorie_offre']) && !empty($_POST['categorie_offre'])
 && isset($_POST['emplacement']) && !empty($_POST['emplacement'])
 && isset($_POST['salaire_min']) && !empty($_POST['salaire_min'])
 && isset($_POST['salaire_max']) && !empty($_POST['salaire_max']) 
 && isset($_POST['nombre_poste']) && !empty($_POST['nombre_poste'])
 && isset($_POST['durée']) && !empty($_POST['durée'])
 && isset($_POST['date_publication']) && !empty($_POST['date_publication'])
 && isset($_POST['description_offre']) && !empty($_POST['description_offre'])){
      
    $titre_offre=$_POST['titre_offre'];
	$type_offre=$_POST['type_offre'];
	$equipe=$_POST['equipe'];
	$categorie_offre=$_POST['categorie_offre'];
	$emplacement=$_POST['emplacement'];
	$salaire_min=$_POST['salaire_min'];
	$salaire_max=$_POST['salaire_max'];
	$nombre_poste=$_POST['nombre_poste'];
	$durée=$_POST['durée'];
	$date_publication=$_POST['date_publication'];
	$description_offre=$_POST['description_offre'];
	
   

     
      $sql = " UPDATE offre_emploi  SET
      titre_offre = '$titre_offre',type_offre = '$type_offre',equipe = '$equipe',categorie_offre = '$categorie_offre',
      emplacement = '$emplacement', salaire_min = '$salaire_min',salaire_max = '$salaire_max',nombre_poste='$nombre_poste',
	 durée = '$durée',date_publication = '$date_publication',description_offre = '$description_offre'
      WHERE id_offreemploi = '".$_GET['id']."'";
      $result=mysqli_query($con,$sql);
      echo"update avec success"; 

 }
  
      
  
  ?>
<html>
<!-- Mirrored from www.vasterad.com/themes/hireo/dashboard-post-a-job.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:39:00 GMT -->
<head>

<!-- Basic Page Needs
================================================== -->
<title>IJA E5DEM</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/colors/blue.css">

</head>
<body class="gray">

<!-- Wrapper -->
<div id="wrapper">
<header id="header-container" class="fullwidth dashboard-header not-sticky">

<!-- Header -->
<div id="header">
	<div class="container">
		
		<!-- Left Side Content -->
		<div class="left-side">
	
<!-- Wrapper -->
			<!-- Logo -->
			<div id="logo">
				<a href="index-2.html"><img src="images/logo.png" alt=""></a>
			</div>

			<!-- Main Navigation -->
			<nav id="navigation">
				<ul id="responsive">

					<li><a href="#">Acceuil</a>
						<ul class="dropdown-nav">
							<li><a href="monprofile.php">Mon profile</a></li>
							<li><a href="jobs-list-layout-user.php">Consulter les offres</a>
						</ul>
					</li>

				
<?php 
  
  $sql1 = "SELECT * FROM offre_emploi WHERE id_offreemploi='".$_GET['id']."'";
  $psw=mysqli_query($con,$sql1);
  while($res=mysqli_fetch_array($psw)) {
	$titre_offre=$res['titre_offre'];
	$type_offre=$res['type_offre'];
	$equipe=$res['equipe'];
	$categorie_offre=$res['categorie_offre'];
	$emplacement=$res['emplacement'];
	$salaire_min=$res['salaire_min'];
	$salaire_max=$res['salaire_max'];
	$nombre_poste=$res['nombre_poste'];
	$date_publication=$res['date_publication'];
	$description_offre=$res['description_offre'];
	
	
   }
?>								
						
							
						</ul>
					</li>
				</ul>
			</nav>
		
		<!-- Left Side Content / End -->

			<!--  User Notifications / End -->

			<!-- User Menu -->
			<div class="header-widget">

				<!-- Messages -->
				<div class="header-notifications user-menu">
					<div class="header-notifications-trigger">
						<a href="#"><div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div></a>
					</div>

					<!-- Dropdown -->
					<div class="header-notifications-dropdown">

						<!-- User Status -->
						<div class="user-status">

							<!-- User Name / Avatar -->
							<div class="user-details">
								<div class="user-avatar status-online"><img src="images/user-avatar-small-01.jpg" alt=""></div>
								<div class="user-name">
									Tom Smith <span>Freelancer</span>
								</div>
							</div>
							
							<!-- User Status Switcher -->
							<div class="status-switch" id="snackbar-user-status">
								<label class="user-online current-status">Online</label>
								<label class="user-invisible">Invisible</label>
								<!-- Status Indicator -->
								<span class="status-indicator" aria-hidden="true"></span>
							</div>	
					</div>
					
					<ul class="user-menu-small-nav">
						<li><a href="monprofile.php"><i class="icon-material-outline-dashboard"></i> Mon profil</a></li>
						<li><a href="dashboard-settings.php"><i class="icon-material-outline-settings"></i> Paramètres</a></li>
						<li><a href="deconnexion.php"><i class="icon-material-outline-power-settings-new"></i> Logout</a></li>
					</ul>

					</div>
				</div>

			</div>
			<!-- User Menu / End -->

			<!-- Mobile Navigation Button -->
			<span class="mmenu-trigger">
				<button class="hamburger hamburger--collapse" type="button">
					<span class="hamburger-box">
						<span class="hamburger-inner"></span>
					</span>
				</button>
			</span>

		</div>
		<!-- Right Side Content / End -->

	</div>
</div>
<!-- Header / End -->

</header>

			<!-- Row -->
			<div class="row">

				<!-- Dashboard Box -->
				<div class="col-xl-12">
					<div class="dashboard-box margin-top-0">

						<!-- Headline -->
						<div class="headline">
							<h3><i class="icon-feather-folder-plus"></i> Formulaire de modification d'offre</h3>
						</div>
                         <form method="post" enctype="multipart/form-data">
						<div class="content with-padding padding-bottom-10">
							<div class="row">
                               <form method="post">
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Titre d'offre</h5>
										<input type="text" class="with-border" value="<?=$titre_offre?>"name="titre_offre">
									</div>
								</div>

								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Type d'offre</h5>
										<select name="type_offre"class="selectpicker with-border" value="<?=$type_offre?>" data-size="7">
											<option value="À plein temps">À plein temps</option>
											<option value="Freelance">Freelance</option>
											<option value="À temps partiel">À temps partiel</option>
											<option value="Stage">Stage</option>
											<option value="Temporary">Temporary</option>
										</select>
									</div>
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Equipe de travail</h5>
										<select name="equipe"class="selectpicker with-border" value="<?=$equipe?>"data-size="7" >
											<option value="MobiSM">MobiSM</option>
											<option value="Autres équipes">Autres équipes</option>
											
										</select>
									</div>
								</div>
                                </div>
								<div class="row">
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>catégorie d'offre</h5>
										<select name="categorie_offre"class="selectpicker with-border" value="<?=$categorie_offre_offre?>"data-size="7" >
											<option value="Comptabilité et finance">Comptabilité et finance</option>
											<option value="Bureau et saisie de données">Bureau et saisie de données</option>
											<option value="Conseils">Conseils</option>
											<option value="Administration des tribunaux">Administration des tribunaux</option>
											<option value="Ressources humaines">Ressources humaines</option>
											<option value="Informatique et ordinateurs">Informatique et ordinateurs</option>
											<option value="Forces de l'ordre">Forces de l'ordre</option>
											<option value="La gestion">La gestion</option>
											<option value="Divers">Divers</option>
											<option value="Relations publiques">Relations publiques</option>
										</select>
									</div>
								</div>

								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Emplacement</h5>
										<div class="input-with-icon">
											<div id="autocomplete-container">
												<input id="autocomplete-input"name="emplacement"class="with-border"value="<?=$emplacement?>"type="text">
											</div>
											<i class="icon-material-outline-location-on"></i>
										</div>
									</div>
								</div>

								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Salaire</h5>
										<div class="row">
											<div class="col-xl-6">
												<div class="input-with-icon">
													<input class="with-border" name="salaire_min" value="<?=$salaire_min?>"type="text" >
													<i class="currency">DT</i>
												</div>
											</div>
											<div class="col-xl-6">
												<div class="input-with-icon">
													<input class="with-border" name="salaire_max" type="text"value="<?=$salaire_max?>">
													<i class="currency">DT</i>
												</div>
											</div>
										</div>
									</div>
								</div>
                                </div>
								<div class="row">
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Nombre de poste   <i class="help-icon" data-tippy-placement="right" ></i></h5>
										<div class="keywords-container">
											<div class="keyword-input-container">
												<input type="text"value="<?=$nombre_poste?>"name="nombre_poste"class="keyword-input with-border" placeholder="e.g. job title, responsibilites"/>
												<button class="keyword-input-button ripple-effect"><i class="icon-material-outline-add"></i></button>
											</div>
											<div class="keywords-list"><!-- keywords go here --></div>
											<div class="clearfix"></div>
										</div>
                                       
									</div>
									
								
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Durée   <i class="help-icon" data-tippy-placement="right" ></i></h5>
										<div class="keywords-container">
											<div class="keyword-input-container">
												<input type="text" name="durée"class="keyword-input with-border"placeholder="en jours"/>
											
											</div>
											<div class="keywords-list"><!-- keywords go here --></div>
											<div class="clearfix"></div>
										</div>
                                       
									</div>
									
								
								</div>
								<div class="col-xl-4">
									<div class="submit-field">
										<h5>Date publication   <i class="help-icon" data-tippy-placement="right" ></i></h5>
										<div class="keywords-container">
											<div class="keyword-input-container">
												<input type="date" name="date_publication"class="keyword-input with-border"value="<?=$date_publication?>"/>
												
											</div>
											<div class="keywords-list"><!-- keywords go here --></div>
											<div class="clearfix"></div>
										</div>
                                       
									</div>
									
								
								</div>
                                </div>
								<div class="col-xl-12">
									<div class="submit-field">
										<h5>Description de l'offre</h5>
										<textarea cols="30" rows="5"name="description_offre"value="<?=$description_offre?>" class="with-border"></textarea>
										
										
									</div>
								</div>
								<div class="col-xl-12">
				                <input type="submit"name="modifier"value="Modifier">
			
				                </div>
								
                                </form>
							</div>
						</div>
					</div>
				</div>

				
               </form>
			</div>
			<!-- Row / End -->

<!-- Footer
================================================== -->
<div id="footer">
	
	<!-- Footer Top Section -->
	<div class="footer-top-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12">

					<!-- Footer Rows Container -->
					<div class="footer-rows-container">
						
						<!-- Left Side -->
						<div class="footer-rows-left">
							<div class="footer-row">
								<div class="footer-row-inner footer-logo">
									<img src="images/logo2.png" alt="">
								</div>
							</div>
						</div>
						
						<!-- Right Side -->
						<div class="footer-rows-right">

							<!-- Social Icons -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<ul class="footer-social-links">
										<li>
											<a href="#" title="Facebook" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-facebook-f"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Twitter" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-twitter"></i>
											</a>
										</li>
										<li>
											<a href="#" title="Google Plus" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-google-plus-g"></i>
											</a>
										</li>
										<li>
											<a href="#" title="LinkedIn" data-tippy-placement="bottom" data-tippy-theme="light">
												<i class="icon-brand-linkedin-in"></i>
											</a>
										</li>
									</ul>
									<div class="clearfix"></div>
								</div>
							</div>
							
							<!-- Language Switcher -->
							<div class="footer-row">
								<div class="footer-row-inner">
									<select class="selectpicker language-switcher" data-selected-text-format="count" data-size="5">
										<option selected>English</option>
										<option>Français</option>
										<option>Español</option>
										<option>Deutsch</option>
									</select>
								</div>
							</div>
						</div>

					</div>
					<!-- Footer Rows Container / End -->
				</div>
			</div>
		</div>
	</div>
	
	<!-- Footer Middle Section -->
	<div class="footer-middle-section">
		<div class="container">
			<div class="row">

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Pour les candidats</h3>
						<ul>
							<li><a href="#"><span>Parcourir les emplois</span></a></li>
							<li><a href="#"><span>Ajouter un CV</span></a></li>
							<li><a href="#"><span>Alertes d'emploi</span></a></li>
							<li><a href="#"><span>Mes marque-pages</span></a></li>
						</ul>
					</div>
				</div>

				<!-- Links -->
				<div class="col-xl-2 col-lg-2 col-md-3">
					<div class="footer-links">
						<h3>Pour les employeurs</h3>
						<ul>
							<li><a href="#"><span>Parcourir les candidats</span></a></li>
							<li><a href="#"><span>Publier une offre</span></a></li>
							<li><a href="#"><span>Publier une tâche</span></a></li>
							<li><a href="#"><span>Plans et prix</span></a></li>
						</ul>
					</div>
				</div>

				
			

				<!-- Newsletter -->
				<div class="col-xl-4 col-lg-4 col-md-12">
					<h3><i class="icon-feather-mail"></i> Inscrivez-vous à une newsletter</h3>
					<p>Dernières nouvelles hebdomadaires, analyses et conseils de pointe sur la recherche d'emploi.</p>
					<form action="#" method="get" class="newsletter">
						<input type="text" name="fname" placeholder="Entrez votre adresse email">
						<button type="submit"><i class="icon-feather-arrow-right"></i></button>
					</form>
				</div>
			</div>
		</div>
	</div>	
	<!-- Footer Middle Section / End -->
	

	

</div>
<!-- Footer / End -->

</div>
<!-- Wrapper / End -->

<!-- Apply for a job popup
================================================== -->

<!-- Apply for a job popup / End -->


<!-- Scripts
================================================== -->
<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/jquery-migrate-3.1.0.min.html"></script>
<script src="js/mmenu.min.js"></script>
<script src="js/tippy.all.min.js"></script>
<script src="js/simplebar.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/snackbar.js"></script>
<script src="js/clipboard.min.js"></script>
<script src="js/counterup.min.js"></script>
<script src="js/magnific-popup.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/custom.js"></script>

<!-- Snackbar // documentation: https://www.polonel.com/snackbar/ -->
<script>
// Snackbar for user status switcher
$('#snackbar-user-status label').click(function() { 
	Snackbar.show({
		text: 'Your status has been changed!',
		pos: 'bottom-center',
		showAction: false,
		actionText: "Dismiss",
		duration: 3000,
		textColor: '#fff',
		backgroundColor: '#383838'
	}); 
}); 

// Snackbar for copy to clipboard button
$('.copy-url-button').click(function() { 
	Snackbar.show({
		text: 'Copied to clipboard!',
	}); 
}); 
</script>

<!-- Google API & Maps -->
<!-- Geting an API Key: https://developers.google.com/maps/documentation/javascript/get-api-key -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&amp;libraries=places"></script>
<script src="js/infobox.min.js"></script>
<script src="js/markerclusterer.js"></script>
<script src="js/maps.js"></script>

</body>

<!-- Mirrored from www.vasterad.com/themes/hireo/single-job-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 19 Oct 2020 13:38:42 GMT -->
</html>