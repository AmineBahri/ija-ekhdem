<?php
include("db.php");


if(!empty($_POST['email']) && isset($_POST['email'])
&& !empty($_POST['sujet'])&& isset($_POST['sujet'])
&& isset($_POST['message']) && !empty($_POST['message']))
{ $email= $_POST['email'];
 $sujet=$_POST['sujet'] ;
 $message= $_POST['message'];
 $sql = " INSERT INTO contact (email,sujet,message) VALUES ('$email' ,'$sujet','$message' );";
$result=mysqli_query($con,$sql);
if(!$result){

die('Error: ' . mysqli_error($con));
}else{
    
// PHP program to pop an alert 
// message box on the screen 

  // Function call 

    header("location: pages-contact.php");
   
echo("<script>alert('file successful deleted!')</script>");
echo("<script>window.location = 'home.php';</script>");

echo "L'email a été envoyé.";}}
?>