-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 21 nov. 2020 à 12:45
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP :  7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ija_ekhdem-1`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(8) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '123456789');

-- --------------------------------------------------------

--
-- Structure de la table `connaissance_linguistiques`
--

CREATE TABLE `connaissance_linguistiques` (
  `id_conling` int(8) NOT NULL,
  `langue_parlee` varchar(255) NOT NULL,
  `niveau_langue` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `connaissance_linguistiques`
--

INSERT INTO `connaissance_linguistiques` (`id_conling`, `langue_parlee`, `niveau_langue`, `id_demandeemp`) VALUES
(121, 'AR', 'Débutant', 31),
(120, 'AR', 'Débutant', 30),
(119, 'francais', 'bien', 29),
(118, 'AR', 'Intermdiaire', 29),
(117, 'hg', 'ggg', 28),
(116, 'ENG', 'Débutant', 28),
(115, 'BNG', 'Débutant', 27),
(100, 'CH', 'Débutant', 12),
(101, 'BNG', 'Débutant', 13),
(102, 'ENG', 'Débutant', 14),
(103, 'AR', 'Débutant', 15),
(104, 'CH', 'Débutant', 16),
(105, 'FR', 'Débutant', 17),
(106, 'AR', 'Débutant', 18),
(107, 'BNG', 'Débutant', 19),
(108, 'AR', 'Débutant', 20),
(109, 'HI', 'Débutant', 21),
(110, 'AR', 'Débutant', 22),
(111, 'CH', 'Débutant', 23),
(112, 'AR', 'Débutant', 24),
(113, 'CH', 'Débutant', 25),
(114, 'FR', 'Débutant', 26);

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

CREATE TABLE `contact` (
  `id_contact` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_estonian_ci NOT NULL,
  `sujet` varchar(255) COLLATE utf8_estonian_ci NOT NULL,
  `message` text COLLATE utf8_estonian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`id_contact`, `email`, `sujet`, `message`) VALUES
(1, 'gerant2@gerant.com', 'hyh', 'yigikj'),
(2, 'zinouba@gmail.com', 'hjgyuh', 'tughblk'),
(3, 'admin@admin.com', 'jhjnhi', 'jubuj'),
(4, 'nanouwalha@gmail.com', 'thghj', 'juf'),
(5, 'zinouba@gmail.com', 'hfty', 'yuhjnk'),
(6, 'zinouba@gmail.com', 'jhg', 'bjk;,'),
(7, 'nanouwalha@gmail.com', 'hgy', 'igb'),
(8, 'zinouba@gmail.com', 'jbhjJ', 'YGUIJ'),
(9, 'gerant@gerant.com', 'hjfr', 'rytgjhk'),
(10, 'nanouwalha@gmail.com', 'jftf', 'tyhujk'),
(11, 'zinouba@gmail.com', 'hdr', 'rtghjk'),
(12, 'nanouwalha@gmail.com', 'hjgreza', 'fghjk');

-- --------------------------------------------------------

--
-- Structure de la table `con_informatique`
--

CREATE TABLE `con_informatique` (
  `id_coninf` int(11) NOT NULL,
  `description_logiciel` varchar(255) NOT NULL,
  `syst_exploitation` varchar(255) NOT NULL,
  `autre_info` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `con_informatique`
--

INSERT INTO `con_informatique` (`id_coninf`, `description_logiciel`, `syst_exploitation`, `autre_info`, `id_demandeemp`) VALUES
(37, 'h jd', 'fjbb', 'jhbj', 31),
(36, '***', 'syst', '***', 30),
(35, '', '', '', 29),
(34, 'bien', 'systeme ', '....', 29),
(33, '', '', '', 28),
(32, 'ggg', 'hy', 'ggg', 28),
(31, 'nhhh', 'nhnd', 'hhh', 12);

-- --------------------------------------------------------

--
-- Structure de la table `demande_emploi`
--

CREATE TABLE `demande_emploi` (
  `id_demandeemp` int(8) NOT NULL,
  `date_demande` date NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_offreemploi` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `demande_emploi1`
--

CREATE TABLE `demande_emploi1` (
  `id_demandeemp` int(8) NOT NULL,
  `date_demande` date NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_offreemploi` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `demande_emploi1`
--

INSERT INTO `demande_emploi1` (`id_demandeemp`, `date_demande`, `id_utilisateur`, `id_offreemploi`) VALUES
(31, '2020-11-21', 8, 16);

-- --------------------------------------------------------

--
-- Structure de la table `diplome`
--

CREATE TABLE `diplome` (
  `id_diplome` int(8) NOT NULL,
  `annee_obtention` date NOT NULL,
  `mention` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL,
  `specialité` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `diplome`
--

INSERT INTO `diplome` (`id_diplome`, `annee_obtention`, `mention`, `id_demandeemp`, `specialité`) VALUES
(31, '2020-11-07', 'Bien', 31, 'jjj'),
(28, '2020-11-06', 'Passable', 0, 'hhh'),
(27, '2020-11-07', 'jdhdh', 12, 'jjj'),
(29, '2020-10-07', 'Bien', 29, 'informatique'),
(30, '2020-10-28', 'Assez bien', 30, 'info'),
(26, '2020-11-12', '<br />\r\n<b>Notice</b>:  Undefined variable: mention in <b>C:xampphtdocsxamppija_ekhdemdemande_post_offre.php</b> on line <b>874</b><br />\r\n', 26, 'd');

-- --------------------------------------------------------

--
-- Structure de la table `experience_professionnelle`
--

CREATE TABLE `experience_professionnelle` (
  `id_expprof` int(8) NOT NULL,
  `poste_occupe` varchar(255) NOT NULL,
  `lieu_experience` varchar(255) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `experience_professionnelle`
--

INSERT INTO `experience_professionnelle` (`id_expprof`, `poste_occupe`, `lieu_experience`, `date_debut`, `date_fin`, `id_demandeemp`) VALUES
(61, 'poste', 'tunis', '2020-11-14', '2020-11-20', 31),
(60, 'poste occupé', 'tunis', '2020-10-14', '2020-10-29', 30),
(59, 'poste', 'marsa', '2020-10-29', '2020-11-04', 29),
(58, 'poste occupé', 'tunis', '2020-10-26', '2020-10-26', 29),
(57, '', '', '0000-00-00', '0000-00-00', 28),
(56, 'hh', 'hhh', '2020-11-06', '2020-10-16', 28),
(55, 'ggg', 'hh', '2020-10-30', '2020-10-31', 12);

-- --------------------------------------------------------

--
-- Structure de la table `formations`
--

CREATE TABLE `formations` (
  `id_formations` int(8) NOT NULL,
  `diplome` varchar(255) NOT NULL,
  `lieu_formation` varchar(255) NOT NULL,
  `duree_formation` varchar(255) NOT NULL,
  `id_demandeemp` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formations`
--

INSERT INTO `formations` (`id_formations`, `diplome`, `lieu_formation`, `duree_formation`, `id_demandeemp`) VALUES
(69, 'jhbffj', 'fnfj', 'in', 31),
(68, 'bac', 'tunis', '3 mois', 30),
(67, '', '', '', 29),
(66, 'Bac', 'tunis', '1 ans', 29),
(65, '', '', '', 28),
(64, 'jhh', 'hhgg', 'ggggggg', 28),
(63, 'hhh', 'hhh', 'ggg', 12);

-- --------------------------------------------------------

--
-- Structure de la table `notification`
--

CREATE TABLE `notification` (
  `id_notification` int(8) NOT NULL,
  `cont_notification` text COLLATE utf8_estonian_ci NOT NULL,
  `notification_status` int(11) NOT NULL,
  `id_utilisateur` int(8) NOT NULL,
  `id_offreemploi` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

--
-- Déchargement des données de la table `notification`
--

INSERT INTO `notification` (`id_notification`, `cont_notification`, `notification_status`, `id_utilisateur`, `id_offreemploi`) VALUES
(1, 'noooooooooooooooooooooooo', 1, 1, 17),
(2, 'nhjjj', 1, 1, 17),
(3, 'sjdsgde', 1, 1, 16),
(4, 'jj', 1, 1, 17),
(5, 'njhhh', 1, 1, 19),
(6, 'hggg', 1, 1, 17),
(7, 'jj', 1, 1, 19),
(8, 'vous etes accepté', 1, 1, 16),
(30, 'vous etes accepté', 1, 8, 16),
(29, 'vous etes accepté', 0, 1, 17),
(28, 'vous etes accepté', 0, 1, 17),
(27, 'vous etes accepté', 0, 8, 17),
(26, 'vous etes accepté', 1, 8, 19);

-- --------------------------------------------------------

--
-- Structure de la table `offre_emploi`
--

CREATE TABLE `offre_emploi` (
  `id_offreemploi` int(8) NOT NULL,
  `titre_offre` varchar(255) NOT NULL,
  `type_offre` varchar(255) NOT NULL,
  `equipe` varchar(255) NOT NULL,
  `categorie_offre` varchar(255) NOT NULL,
  `emplacement` varchar(255) NOT NULL,
  `salaire_min` varchar(255) NOT NULL,
  `salaire_max` varchar(255) NOT NULL,
  `nombre_poste` varchar(255) NOT NULL,
  `durée` varchar(255) NOT NULL,
  `date_publication` varchar(255) NOT NULL,
  `description_offre` varchar(5000) NOT NULL,
  `image` varchar(255) NOT NULL,
  `id_utilisateur` int(8) DEFAULT NULL,
  `id_permorale` int(8) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `offre_emploi`
--

INSERT INTO `offre_emploi` (`id_offreemploi`, `titre_offre`, `type_offre`, `equipe`, `categorie_offre`, `emplacement`, `salaire_min`, `salaire_max`, `nombre_poste`, `durée`, `date_publication`, `description_offre`, `image`, `id_utilisateur`, `id_permorale`) VALUES
(17, 'Responsable developpemnt RH', 'Freelance', 'MobiSM', 'ComptabilitÃ© et finance', 'soliman', '100', '1700', '4', '5 jours', '2020-10-28', 'azsdcv', 'neoxam.png', 2, 7),
(16, 'Charge Recherche & DÃ©veloppement', 'Ã€ plein temps', 'MobiSM', 'ComptabilitÃ© et finance', 'El manzah 6 tunis', '600', '700', '3', '4jours', '2020-10-30', 'azertyuiop\r\nmlkjhgfdsq\r\nwxcvbn,;', 'neoxam.png', 4, 7),
(18, 'test', 'Ã€ plein temps', 'Autres Ã©quipes', 'Ressources humaines', 'avenue habib Mohamed Khames tunis', '100', '1000', '5', '3jours', '2020-10-30', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'amel_kadhraoui.jpg', 2, 8),
(19, '****', 'À plein temps', 'MobiSM', 'Bureau et saisie de données', 'tunis', '120', '200', 'jdjdj', '3 mois', '2020-11-05', '*****', '', NULL, 7);

-- --------------------------------------------------------

--
-- Structure de la table `personne_morale`
--

CREATE TABLE `personne_morale` (
  `id_persmorale` int(8) NOT NULL,
  `cin` int(8) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `nom_societe` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL,
  `domaine` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `personne_morale`
--

INSERT INTO `personne_morale` (`id_persmorale`, `cin`, `nom`, `prenom`, `nom_societe`, `email`, `password`, `adresse`, `telephone`, `date_naissance`, `domaine`) VALUES
(7, 101010101, 'dhia', 'hannachi', 'MobiSm', 'dhia@gmail.com', 'dhia1234', 'Avenue HAbib bourguiba jendouba8100', '123555555', '2020-10-23', 'developpementt'),
(9, 11111111, 'Mohamed', 'abidi', 'MobiSmm', 'mohamed@gmail.com', 'mohamed', 'Avenue HAbib bourguiba tunis', '23445666', '2020-10-14', 'developpementt'),
(8, 0, 'meriem', 'abidi', 'MobiSmm', 'meriem@gmail.com', '123456789', 'Avenue HAbib bourguiba tunis', '1111111111', '2020-10-30', 'developpementt'),
(10, 0, 'meriem', 'khemiri', 'MobiSm', 'meriem@gmail.com', 'meriem1234', 'el manzah 6 tunis', '00000000', '2020-10-29', 'developpement'),
(11, 0, 'test1', 'st1', 'test', 'test@gmail.com', '1234', 'test', '1111111111', '2020-10-29', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `projet`
--

CREATE TABLE `projet` (
  `id_projet` int(11) NOT NULL,
  `nom_projet` varchar(30) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `url_projet` text CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `prix_projet` int(11) NOT NULL,
  `competences` text CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `date_depot` date DEFAULT NULL,
  `id_utilisateur` int(8) NOT NULL,
  `id_offreemploi` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `projet`
--

INSERT INTO `projet` (`id_projet`, `nom_projet`, `url_projet`, `prix_projet`, `competences`, `date_depot`, `id_utilisateur`, `id_offreemploi`) VALUES
(22, 'ija_ekhdem.zip', '../Personne_morale/files/ija_ekhdem.zip', 0, 'vdd', '2020-11-08', 8, 19),
(21, 'ija_ekhdem.zip', '../Personne_morale/files/ija_ekhdem.zip', 0, 'ygy', '2020-11-08', 8, 19),
(20, 'ija_ekhdem.zip', '../Personne_morale/files/ija_ekhdem.zip', 0, 'hbhb', '2020-11-07', 1, 17);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `id_utilisateur` int(8) NOT NULL,
  `cin` int(8) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` varchar(255) NOT NULL,
  `date_naissance` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_utilisateur`, `cin`, `nom`, `prenom`, `email`, `password`, `adresse`, `telephone`, `date_naissance`) VALUES
(1, 12345678, 'henda', 'ilhem', 'admin@gmail.com', 'nanou123', 'el hneydiya hedi ben hssine jendouba', '23468853', '2020-07-31'),
(2, 123456789, 'dhia', 'hannachi', 'bb@gmail.com', '123456789', 'aaaaaaaaaaaaanjkk', '123456789', '2020-08-18'),
(4, 7992639, 'henda', 'ilhem', 'ilhembenhenda23@gmail.com', 'ilhem2020', 'el hneydiya hedi ben hssine jendouba', '23468853', '2020-10-07'),
(9, 14766164, 'henda', 'walha', 'henda@gmail.com', '123456789', 'tunis', '55441544', '2002-02-05'),
(8, 14766164, 'walha', 'nesrine', 'nesrine@gmail.com', '123456789', 'charles de gaule', '54323750', '1997-01-12');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `connaissance_linguistiques`
--
ALTER TABLE `connaissance_linguistiques`
  ADD PRIMARY KEY (`id_conling`),
  ADD KEY `id_demandeemp` (`id_demandeemp`);

--
-- Index pour la table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id_contact`);

--
-- Index pour la table `con_informatique`
--
ALTER TABLE `con_informatique`
  ADD PRIMARY KEY (`id_coninf`),
  ADD KEY `id_demandeemp` (`id_demandeemp`);

--
-- Index pour la table `demande_emploi`
--
ALTER TABLE `demande_emploi`
  ADD PRIMARY KEY (`id_demandeemp`),
  ADD KEY `id_utilisateur` (`id_utilisateur`),
  ADD KEY `id_offreemploi` (`id_offreemploi`);

--
-- Index pour la table `demande_emploi1`
--
ALTER TABLE `demande_emploi1`
  ADD PRIMARY KEY (`id_demandeemp`),
  ADD KEY `id_utilisateur` (`id_utilisateur`),
  ADD KEY `id_offreemploi` (`id_offreemploi`);

--
-- Index pour la table `diplome`
--
ALTER TABLE `diplome`
  ADD PRIMARY KEY (`id_diplome`),
  ADD KEY `id_demandeemp` (`id_demandeemp`);

--
-- Index pour la table `experience_professionnelle`
--
ALTER TABLE `experience_professionnelle`
  ADD PRIMARY KEY (`id_expprof`),
  ADD KEY `id_demandeemp` (`id_demandeemp`);

--
-- Index pour la table `formations`
--
ALTER TABLE `formations`
  ADD PRIMARY KEY (`id_formations`),
  ADD KEY `id_demandeemp` (`id_demandeemp`);

--
-- Index pour la table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id_notification`),
  ADD KEY `id_utilisateur` (`id_utilisateur`),
  ADD KEY `id_offreemploi` (`id_offreemploi`);

--
-- Index pour la table `offre_emploi`
--
ALTER TABLE `offre_emploi`
  ADD PRIMARY KEY (`id_offreemploi`),
  ADD KEY `id_utilisateur` (`id_utilisateur`),
  ADD KEY `id_permorale` (`id_permorale`);

--
-- Index pour la table `personne_morale`
--
ALTER TABLE `personne_morale`
  ADD PRIMARY KEY (`id_persmorale`);

--
-- Index pour la table `projet`
--
ALTER TABLE `projet`
  ADD PRIMARY KEY (`id_projet`),
  ADD KEY `id_utilisateur` (`id_utilisateur`),
  ADD KEY `id_offreemploi` (`id_offreemploi`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`id_utilisateur`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `connaissance_linguistiques`
--
ALTER TABLE `connaissance_linguistiques`
  MODIFY `id_conling` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT pour la table `contact`
--
ALTER TABLE `contact`
  MODIFY `id_contact` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `con_informatique`
--
ALTER TABLE `con_informatique`
  MODIFY `id_coninf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `demande_emploi`
--
ALTER TABLE `demande_emploi`
  MODIFY `id_demandeemp` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `demande_emploi1`
--
ALTER TABLE `demande_emploi1`
  MODIFY `id_demandeemp` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT pour la table `diplome`
--
ALTER TABLE `diplome`
  MODIFY `id_diplome` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `experience_professionnelle`
--
ALTER TABLE `experience_professionnelle`
  MODIFY `id_expprof` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT pour la table `formations`
--
ALTER TABLE `formations`
  MODIFY `id_formations` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT pour la table `notification`
--
ALTER TABLE `notification`
  MODIFY `id_notification` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT pour la table `offre_emploi`
--
ALTER TABLE `offre_emploi`
  MODIFY `id_offreemploi` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `personne_morale`
--
ALTER TABLE `personne_morale`
  MODIFY `id_persmorale` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `projet`
--
ALTER TABLE `projet`
  MODIFY `id_projet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `id_utilisateur` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
